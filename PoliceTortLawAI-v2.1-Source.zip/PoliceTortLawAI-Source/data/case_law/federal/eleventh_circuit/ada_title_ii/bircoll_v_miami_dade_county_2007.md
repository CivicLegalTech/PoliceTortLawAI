# Bircoll v. Miami-Dade County

**Citation:** 480 F.3d 1072 (11th Cir. 2007)

**Court:** U.S. Court of Appeals for the Eleventh Circuit

**Authority:** binding federal circuit precedent

**Outcome:** County prevailed on the disability-accommodation claim on the facts presented.

**Rule / holding summary:** ADA Title II can reach police interactions; whether modifications are reasonable depends on circumstances, including safety and effective communication.

**Relevance:** Relevant to police communication accommodations; distinguish DUI arrest from receiving a report.

**Full opinion/source:** https://caselaw.findlaw.com/court/us-11th-circuit/1360320.html

*Research summary only. Subsequent history not independently verified.*
