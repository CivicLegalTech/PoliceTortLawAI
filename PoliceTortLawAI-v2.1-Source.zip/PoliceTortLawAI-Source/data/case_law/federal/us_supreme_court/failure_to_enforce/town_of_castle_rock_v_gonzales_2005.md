# Town of Castle Rock v. Gonzales

**Citation:** 545 U.S. 748 (2005)

**Court:** Supreme Court of the United States

**Authority:** binding federal constitutional precedent

**Outcome:** Town prevailed; no procedural due process property entitlement to police enforcement of restraining order under Colorado law.

**Rule / holding summary:** A statutory instruction to enforce a restraining order did not establish the claimed federal property entitlement to enforcement in this case.

**Relevance:** Critical adverse authority for due-process theories based only on police nonenforcement; distinguish ADA and state tort theories.

**Full opinion/source:** https://supreme.justia.com/cases/federal/us/545/748/

*Research summary only. Subsequent history not independently verified.*
