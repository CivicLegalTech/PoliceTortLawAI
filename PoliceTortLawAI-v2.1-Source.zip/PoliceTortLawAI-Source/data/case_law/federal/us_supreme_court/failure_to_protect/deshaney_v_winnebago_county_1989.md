# DeShaney v. Winnebago County Department of Social Services

**Citation:** 489 U.S. 189 (1989)

**Court:** Supreme Court of the United States

**Authority:** binding federal constitutional precedent

**Outcome:** Defendants prevailed; no general substantive due process duty to protect from private violence absent qualifying custody or state action.

**Rule / holding summary:** State knowledge of danger and expressions of intent to help generally do not alone create a federal constitutional duty to protect from private actors. State tort duty is a separate question.

**Relevance:** Critical adverse authority for section 1983 failure-to-protect theories; not a holding about ADA Title II or Florida negligence.

**Full opinion/source:** https://www.govinfo.gov/content/pkg/USREPORTS-489/pdf/USREPORTS-489-189.pdf

*Research summary only. Subsequent history not independently verified.*
