# Kaisner v. Kolb

**Citation:** 543 So. 2d 732  
**Court:** Florida Supreme Court  
**Decided:** 1989-03-30  
**Docket:** 71121

## Case outcome
Florida Supreme Court quashed adverse appellate decision and remanded.

## Relevance
Police detention and foreseeable zone of risk; distinguishes operational conduct from protected planning-level decisions.

## Opinion source
https://law.justia.com/cases/florida/supreme-court/1989/71121-0.html

**Important:** This is a research reference, not the complete judicial opinion. Verify the holding and subsequent treatment before citing.
