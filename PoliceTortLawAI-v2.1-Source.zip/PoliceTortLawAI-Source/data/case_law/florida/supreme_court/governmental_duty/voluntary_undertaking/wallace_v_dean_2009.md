# Wallace v. Dean

**Citation:** 3 So. 3d 1035  
**Court:** Florida Supreme Court  
**Decided:** 2009-01-29  
**Docket:** SC08-149

## Case outcome
Plaintiff prevailed on appeal; case remanded; final monetary outcome not verified.

## Relevance
Analyzes when deputies’ affirmative undertaking can create a duty of reasonable care. Do not classify as a final damages award.

## Opinion source
https://law.justia.com/cases/florida/supreme-court/2009/

**Important:** This is a research reference, not the complete judicial opinion. Verify the holding and subsequent treatment before citing.
