# Pollock v. Florida Department of Highway Patrol

**Citation:** 882 So. 2d 928 (Fla. 2004)

**Court:** Florida Supreme Court

**Authority:** binding statewide

**Outcome:** Plaintiffs did not establish duty; agency protocols did not independently create a tort duty.

**Rule / holding summary:** A police agency manual or dispatch protocol does not, by itself, create an individual tort duty. Duty must be determined before sovereign immunity.

**Relevance:** Important adverse authority when a claim rests solely on an officer not taking a report or following an internal policy.

**Full opinion/source:** https://flcourts-media.flcourts.gov/content/download/325221/opinion/Opinion_SC99-8.pdf

*Research summary only. Subsequent history not independently verified.*
