# Trianon Park Condominium Assn. v. City of Hialeah

**Citation:** 468 So. 2d 912  
**Court:** Florida Supreme Court  
**Decided:** 1985-04-04  
**Docket:** 63115

## Case outcome
City prevailed in Florida Supreme Court; adverse decision to plaintiff.

## Relevance
Enforcement of general police-power functions does not automatically establish an individual common-law duty; §768.28 does not itself create a duty.

## Opinion source
https://law.justia.com/cases/florida/supreme-court/1985/63115-0.html

**Important:** This is a research reference, not the complete judicial opinion. Verify the holding and subsequent treatment before citing.
