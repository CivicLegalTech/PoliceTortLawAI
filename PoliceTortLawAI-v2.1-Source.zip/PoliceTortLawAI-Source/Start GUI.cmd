@echo off
cd /d "%~dp0"
python app\screenshot_gui.py
pause
