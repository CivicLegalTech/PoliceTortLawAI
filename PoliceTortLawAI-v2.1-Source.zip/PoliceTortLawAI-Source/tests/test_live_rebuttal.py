import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1] / 'app'))
from live_rebuttal import validate_review, review_statement

class EvidenceGateTests(unittest.TestCase):
    def setUp(self):
        self.statement='The test folder is red and not blue.'
        self.sources=[{'content':'The test folder is blue.', 'title':'Synthetic fixture'}]
        self.answer={'decision':'possible_rebuttal','reason':'Colors differ.',
            'statement_quote':'The test folder is red',
            'evidence':[{'source':1,'quote':'The test folder is blue.'}], 'draft':'Please check the folder color.'}

    def test_exact_quotes_pass(self):
        self.assertEqual(validate_review(self.answer,self.statement,self.sources)['decision'],'possible_rebuttal')

    def test_fabricated_quote_suppressed(self):
        self.answer['evidence'][0]['quote']='The test folder is green.'
        self.assertEqual(validate_review(self.answer,self.statement,self.sources)['decision'],'needs_context')

    def test_unknown_source_suppressed(self):
        self.answer['evidence'][0]['source']=9
        self.assertFalse(validate_review(self.answer,self.statement,self.sources)['evidence'])

    def test_misquoted_statement_suppressed(self):
        self.answer['statement_quote']='The witness was never there.'
        self.assertEqual(validate_review(self.answer,self.statement,self.sources)['decision'],'needs_context')

    def test_no_evidence_abstains_without_server(self):
        self.assertEqual(review_statement(self.statement,[])['decision'],'needs_context')

    def test_low_recognition_abstains_without_server(self):
        self.assertEqual(review_statement(self.statement,self.sources,.4)['decision'],'needs_context')

    def test_nonalert_cannot_supply_draft(self):
        self.answer['decision']='no_supported_rebuttal'
        self.assertEqual(validate_review(self.answer,self.statement,self.sources)['draft'],'')

if __name__=='__main__':unittest.main()
