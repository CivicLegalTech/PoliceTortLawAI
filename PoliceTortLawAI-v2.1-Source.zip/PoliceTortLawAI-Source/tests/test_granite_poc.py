import json
import gc
import importlib.util
import pathlib
import sqlite3
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'app'))
import local_ai
import rag

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps({'status': 'ok'}).encode('utf-8'))
    def do_POST(self):
        length = int(self.headers.get('Content-Length', 0))
        payload = json.loads(self.rfile.read(length))
        assert payload['messages'][0]['role'] == 'system'
        assert payload['messages'][1]['role'] == 'user'
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps({'choices':[{'message':{'content': 'The source reports a refusal [S1]. The legal theory needs evidence.'}}]}).encode('utf-8'))
    def log_message(self,*args):
        pass

class GranitePOCTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.tempdir=pathlib.Path(self.temp.name)
        self.orig_db=rag.DB
        rag.DB=self.tempdir/'test_rag.sqlite3'
    def tearDown(self):
        rag.DB=self.orig_db
        gc.collect()
        self.temp.cleanup()

    def test_page_aware_search_and_update(self):
        path = self.tempdir/'brief.txt'
        path.write_text('[Page 1]\nOfficer declined to take report.\n[Page 2]\nPlaintiff discusses sovereign immunity.',encoding='utf-8')
        self.assertEqual(rag.ingest_path(path),1)
        self.assertEqual(rag.ingest_path(path),0)
        first=rag.search('officer report')
        self.assertEqual(first[0]['page'],1)
        self.assertIn('Officer declined',first[0]['content'])
        self.assertEqual(rag.search('sovereign immunity')[0]['page'],2)
        path.write_text('[Page 1]\nThe officers gave a receipt only.',encoding='utf-8')
        self.assertEqual(rag.ingest_path(path),1)
        self.assertEqual(rag.search('sovereign immunity'),[])

    def test_case_index(self):
        folder = self.tempdir/'cases';folder.mkdir()
        (folder/'test.json').write_text(json.dumps({'case_name':'Test v. Town', 'citation':'1 So. 2d 22', 'case_summary':'A public duty defense applies.', 'verification_status':'unverified'}),encoding='utf-8')
        self.assertEqual(rag.index_case_summaries(folder),1)
        self.assertEqual(rag.index_case_summaries(folder),0)
        match=rag.search('public duty')[0]
        self.assertEqual(match['kind'],'case_summary')
        self.assertEqual(match['verification_status'],'unverified')


    @unittest.skipUnless(importlib.util.find_spec('numpy'), 'Optional embeddings require numpy')
    def test_optional_semantic_embedding_index(self):
        import numpy as np
        rag.index_text('doc:one','Report','Officer declined a report.',verification_status='user supplied')
        rag.index_text('doc:two','Court','The court ruled on procedure.',verification_status='user supplied')
        class FakeEncoder:
            def encode(self,text,**kwargs):
                def vec(s):
                    return np.array([1.,0.], dtype=np.float32) if 'report' in s.lower() else np.array([0.,1.],dtype=np.float32)
                return np.array([vec(t) for t in text]) if isinstance(text,list) else vec(text)
        with patch.object(rag,'encoder', return_value=FakeEncoder()), \
             patch.object(rag,'embedding_location',return_value=self.tempdir):
            self.assertEqual(rag.build_embeddings(),2)
            self.assertEqual(rag.stats()['embedded_chunks'],2)
            self.assertIn('Report', [r['title'] for r in rag.search('report',limit=2)])

    def test_loopback_only_and_chat(self):
        with patch.dict('os.environ', {'TORTLAW_AI_ENDPOINT':'https://remote-cloud.example'},clear=False):
            with self.assertRaises(ValueError):local_ai.endpoint()
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True)
        thread.start()
        try:
            with patch.dict('os.environ', {'TORTLAW_AI_ENDPOINT':f'http://127.0.0.1:{server.server_port}'},clear=False), patch('urllib.request.getproxies',return_value={}):
                self.assertTrue(local_ai.status().startswith('AI available'))
                result=local_ai.complete('What happened?', [{'title':'Report', 'content':'The officer refused the report.', 'verification_status':'user supplied'}])
                self.assertIn('[S1]',result)
                self.assertIn('NOT verified case citations',result)
        finally:
            server.shutdown()
            server.server_close()

if __name__=='__main__':unittest.main()
