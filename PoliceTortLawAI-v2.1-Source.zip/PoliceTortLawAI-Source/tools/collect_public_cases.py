"""Bounded, attributable CourtListener opinion search importer. Standard library only.

Requires COURTLISTENER_TOKEN environment variable. Does not access PACER or RECAP Fetch.
"""
import argparse, datetime, hashlib, json, os, pathlib, sqlite3, time, urllib.parse, urllib.request, urllib.error
BASE='https://www.courtlistener.com'
SEARCH=BASE+'/api/rest/v4/search/'
QUERIES=['"failure to investigate" police','"refused to take a report" police','"qualified immunity" "police"','"Monell" "police"','"Title II" "police"']
def main():
    p=argparse.ArgumentParser();p.add_argument('--max-per-query',type=int,default=5);p.add_argument('--delay',type=float,default=13.0);p.add_argument('--dry-run',action='store_true');p.add_argument('--output',default=str(pathlib.Path.home()/'PoliceTortLawAI'/'public_cases'));a=p.parse_args()
    if not 1<=a.max_per_query<=20: p.error('--max-per-query must be 1..20')
    if a.delay<12: p.error('--delay must be at least 12 seconds')
    output=pathlib.Path(a.output);output.mkdir(parents=True,exist_ok=True)
    token=os.environ.get('COURTLISTENER_TOKEN','')
    if not token and not a.dry_run:p.error('Set COURTLISTENER_TOKEN in your environment (do not put it in the source code)')
    con=sqlite3.connect(output/'sources.sqlite3')
    con.execute('CREATE TABLE IF NOT EXISTS sources (source_id TEXT PRIMARY KEY, title TEXT, url TEXT, court TEXT, date_filed TEXT, retrieved_utc TEXT, query TEXT, sha256 TEXT, raw_path TEXT)')
    con.execute('CREATE VIRTUAL TABLE IF NOT EXISTS source_fts USING fts5(source_id UNINDEXED,title,text)')
    total=0
    for query in QUERIES:
        url=SEARCH+'?'+urllib.parse.urlencode({'q':query,'type':'o'})
        if a.dry_run:print('WOULD QUERY',url);continue
        req=urllib.request.Request(url,headers={'Authorization':'Token '+token,'User-Agent':'PoliceTortLawAI-public-research/1.0 (attributed case research)','Accept':'application/json'})
        try:
            with urllib.request.urlopen(req,timeout=30) as response:payload=json.load(response)
        except urllib.error.HTTPError as exc:
            print('HTTP',exc.code,'for',query,'(stopping; check credentials, limits and permissions)');break
        except Exception as exc:
            print('Request failed:',str(exc));break
        for hit in payload.get('results',[])[:a.max_per_query]:
            sid=str(hit.get('id') or hashlib.sha256(json.dumps(hit,sort_keys=True).encode()).hexdigest()[:20])
            title=str(hit.get('caseName') or hit.get('case_name') or hit.get('caseNameFull') or 'Untitled')
            path=str(hit.get('absolute_url') or '')
            if not path.startswith('/'):path=''
            source_url=BASE+path if path else url
            text=str(hit.get('snippet') or hit.get('text') or '')
            if not text.strip():continue
            raw=json.dumps({'provider':'CourtListener','query':query,'source_url':source_url,'record':hit},indent=2,ensure_ascii=False)
            digest=hashlib.sha256(raw.encode()).hexdigest();filename=output/(digest+'.json')
            filename.write_text(raw,encoding='utf-8')
            con.execute('INSERT OR IGNORE INTO sources VALUES (?,?,?,?,?,?,?,?,?)',(sid,title,source_url,str(hit.get('court') or ''),str(hit.get('dateFiled') or ''),datetime.datetime.now(datetime.timezone.utc).isoformat(),query,digest,str(filename)))
            con.execute('DELETE FROM source_fts WHERE source_id=?',(sid,))
            con.execute('INSERT INTO source_fts VALUES (?,?,?)',(sid,title,text))
            total+=1
        con.commit();print('Indexed',query,'total',total);time.sleep(a.delay)
    con.close();print('Done. Indexed excerpts are search results, NOT verified full opinions. Total:',total)
if __name__=='__main__':main()
