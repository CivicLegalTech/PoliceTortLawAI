"""Build and query an offline SQLite case-summary index. Python standard library only.
Usage: python tools/case_summary_search.py build
       python tools/case_summary_search.py search "police report refusal" --limit 8
       python tools/case_summary_search.py stats
"""
import argparse, json, sqlite3, pathlib, re
ROOT=pathlib.Path(__file__).resolve().parents[1]
SOURCE=ROOT/'data'/'case_law'/'research_summaries_v2_1'
DB=ROOT/'data'/'case_law'/'case_summaries_search.sqlite3'

def records():
    for path in sorted(SOURCE.rglob('*.json')):
        if path.name=='index.json': continue
        try: item=json.loads(path.read_text(encoding='utf-8'))
        except (ValueError,OSError): continue
        if isinstance(item,dict) and item.get('case_name'):
            yield path,item

def key(item):
    citation=str(item.get('citation','')).lower().strip()
    if citation: return 'cite:'+re.sub(r'\s+',' ',citation)
    return 'name:'+re.sub(r'[^a-z0-9]','',str(item.get('case_name','')).lower())

def connect():
    DB.parent.mkdir(parents=True,exist_ok=True)
    return sqlite3.connect(DB)

def build():
    con=connect()
    con.execute('DROP TABLE IF EXISTS cases_fts')
    con.execute('DROP TABLE IF EXISTS cases')
    con.execute('CREATE TABLE cases(id INTEGER PRIMARY KEY, identity_key TEXT UNIQUE, case_name TEXT, citation TEXT, summary TEXT, relevance TEXT, verification_status TEXT, source_path TEXT, source_lookup TEXT)')
    con.execute('CREATE VIRTUAL TABLE cases_fts USING fts5(case_name, citation, summary, relevance, content="cases", content_rowid="id")')
    duplicates=[]; added=0
    for path,item in records():
        identity=key(item)
        try:
            con.execute('INSERT INTO cases(identity_key,case_name,citation,summary,relevance,verification_status,source_path,source_lookup) VALUES (?,?,?,?,?,?,?,?)',(
                identity,str(item.get('case_name','')),str(item.get('citation','')),str(item.get('case_summary','')),str(item.get('relevance','')),
                str(item.get('verification_status','unverified')),str(path.relative_to(ROOT)),str(item.get('source_lookup',''))))
            added+=1
        except sqlite3.IntegrityError: duplicates.append(str(path.relative_to(ROOT)))
    con.execute('INSERT INTO cases_fts(cases_fts) VALUES ("rebuild")')
    con.commit();con.close()
    print(f'Indexed {added} distinct case-summary records; skipped {len(duplicates)} duplicate citation/name keys.')
    if duplicates: print('Duplicate files:',*duplicates,sep='\n - ')
    print('Note: indexing does NOT verify the underlying opinions or subsequent history.')

def search(query,limit):
    if not DB.exists(): raise SystemExit('Index missing. Run: python tools/case_summary_search.py build')
    con=connect();con.row_factory=sqlite3.Row
    # Use phrase-safe tokenized query to avoid FTS query syntax errors from natural-language input.
    terms=re.findall(r'[\w]+',query,flags=re.UNICODE)
    if not terms: raise SystemExit('Enter search terms.')
    fts=' OR '.join('"'+t.replace('"','')+'"' for t in terms[:12])
    rows=con.execute('SELECT c.*,bm25(cases_fts) AS score FROM cases_fts JOIN cases c ON c.id=cases_fts.rowid WHERE cases_fts MATCH ? ORDER BY score LIMIT ?', (fts,max(1,min(limit,100)))).fetchall()
    for row in rows:
        print(f'\n{row["case_name"]} | {row["citation"]}\n{row["summary"]}\nRelevance: {row["relevance"]}\nVerification: {row["verification_status"]}\nFile: {row["source_path"]}')
    print(f'\n{len(rows)} result(s). Source verification required before legal reliance.')
    con.close()

def stats():
    total=sum(1 for _ in records())
    if not DB.exists(): print(f'{total} JSON summary files; index not built');return
    con=connect();indexed=con.execute('SELECT COUNT(*) FROM cases').fetchone()[0];con.close()
    print(f'{total} JSON summary files; {indexed} distinct indexed cases; {total-indexed} duplicates by citation/name key')

if __name__=='__main__':
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('build');s=sub.add_parser('search');s.add_argument('query');s.add_argument('--limit',type=int,default=8);sub.add_parser('stats')
    args=p.parse_args()
    if args.command=='build':build()
    elif args.command=='search':search(args.query,args.limit)
    else:stats()
