"""Build local BGE embeddings for hybrid retrieval. Requires explicit model installation."""
import pathlib
import sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app'))
import rag
if __name__=='__main__':
    rag.sync_library()
    rag.index_case_summaries()
    print('New or updated embeddings:', rag.build_embeddings())
    print(rag.stats())
