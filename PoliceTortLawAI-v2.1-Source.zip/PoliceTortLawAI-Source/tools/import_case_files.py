"""Offline, opt-in batch importer for local case files; no GUI changes."""
import argparse
import hashlib
import pathlib
import sqlite3
import sys
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
from desktop import connect, extract

SUPPORTED = {".pdf", ".docx", ".txt", ".md", ".csv"}
MAX_BYTES = 80 * 1024 * 1024

def collect(paths):
    for raw in paths:
        path = pathlib.Path(raw).expanduser().resolve()
        if path.is_dir():
            yield from (p for p in sorted(path.rglob("*")) if p.is_file() and p.suffix.lower() in SUPPORTED)
        elif path.is_file() and path.suffix.lower() in SUPPORTED:
            yield path
        else:
            print(f"SKIP unsupported or missing: {path}", file=sys.stderr)

def import_files(paths):
    con = connect()
    imported = 0
    failed = 0
    try:
        for path in dict.fromkeys(collect(paths)):
            try:
                if path.stat().st_size > MAX_BYTES:
                    raise ValueError("file exceeds 80 MB limit")
                content = extract(path)
                if not content.strip():
                    raise ValueError("no extractable text (scanned PDF may require OCR)")
                digest = hashlib.sha256(path.read_bytes()).hexdigest()
                with con:
                    con.execute("INSERT INTO documents(name,path,imported_utc,text) VALUES(?,?,?,?) ON CONFLICT(path) DO UPDATE SET name=excluded.name,imported_utc=excluded.imported_utc,text=excluded.text", (path.name,str(path),datetime.now(timezone.utc).isoformat(),content))
                    doc_id = con.execute("SELECT id FROM documents WHERE path=?", (str(path),)).fetchone()[0]
                    con.execute("DELETE FROM evidence WHERE document_id=?", (doc_id,))
                    con.execute("INSERT INTO evidence(document_id,sha256,source_type) VALUES(?,?,?)", (doc_id,digest,path.suffix.lower()))
                imported += 1
                print(f"IMPORTED {path.name}")
            except Exception as exc:
                failed += 1
                print(f"ERROR {path}: {exc}", file=sys.stderr)
    finally:
        con.close()
    print(f"Done: {imported} imported/updated, {failed} failed. Originals unchanged.")
    return 1 if failed else 0

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Index supplied case files locally into the existing Police TortLaw AI document library")
    parser.add_argument("paths", nargs="*", default=[str(ROOT / "data" / "on_demand_cases" / "incoming")])
    args = parser.parse_args()
    raise SystemExit(import_files(args.paths))
