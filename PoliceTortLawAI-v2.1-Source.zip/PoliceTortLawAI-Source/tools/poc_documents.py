"""POC CLI: ingest local documents, retrieve exact-source excerpts, optionally ask local AI.

Examples:
  py tools\\poc_documents.py import C:\\research
  py tools\\poc_documents.py ask "Was the report refused?"
  py tools\\poc_documents.py ask "What defenses apply?" --ai
"""
import argparse
import pathlib
import sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app'))
import rag
import local_ai


def run():
    parser=argparse.ArgumentParser(description='Police TortLaw AI v2.1 offline research POC')
    cmd=parser.add_subparsers(dest='command',required=True)
    imp=cmd.add_parser('import',help='Index PDF, DOCX, TXT, MD and other source files')
    imp.add_argument('path')
    ask=cmd.add_parser('ask',help='Retrieve source evidence, optionally generate a local answer')
    ask.add_argument('question')
    ask.add_argument('--ai',action='store_true',help='Ask a running local llama.cpp Granite server')
    cmd.add_parser('stats')
    a=parser.parse_args()
    if a.command=='import':
        print('Imported/updated:',rag.ingest_path(a.path))
        print('Case summaries indexed/updated:',rag.index_case_summaries())
    elif a.command=='stats':
        print(rag.stats())
    elif a.command=='ask':
        rag.index_case_summaries()
        rag.sync_library()
        sources=rag.search(a.question,limit=6)
        if not sources:
            print('No matching passages; import documents or try a different question.')
            return
        for i,s in enumerate(sources,1):
            print(f'[S{i}] {s["title"]} | page {s["page"] or "N/A"} | '+
                  f'verification: {s["verification_status"]} | {s["citation"]}')
        if a.ai:
            print('\nAI DRAFT (human verification required):\n'+local_ai.complete(a.question,sources))
        else:
            print('\nRETRIEVED PASSAGES (no AI model called):')
            for i,s in enumerate(sources,1):
                print(f'\n[S{i}] {s["content"][:600]}')
if __name__=='__main__':run()
