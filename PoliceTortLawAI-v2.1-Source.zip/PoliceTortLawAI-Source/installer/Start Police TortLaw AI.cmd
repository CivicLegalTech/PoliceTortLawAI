@echo off
setlocal
cd /d "%~dp0"
set "PYTHONNOUSERSITE=1"
set "PYTHONDONTWRITEBYTECODE=1"
"%~dp0python\python.exe" "%~dp0launch.py"
if errorlevel 1 pause
