"""Offline restore installer. No admin access, downloads or security changes."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tkinter as tk
from tkinter import filedialog, messagebox

ROOT=Path(__file__).resolve().parent


def verify():
    manifest=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    for relative,expected in manifest.items():
        path=ROOT/relative
        if not path.is_file():raise RuntimeError('Missing bundle file: '+relative)
        digest=hashlib.sha256()
        with path.open('rb') as source:
            for block in iter(lambda:source.read(4*1024*1024),b''):digest.update(block)
        if digest.hexdigest()!=expected:raise RuntimeError('Integrity check failed: '+relative)


def main():
    ui=tk.Tk();ui.withdraw()
    messagebox.showinfo('Install Police TortLaw AI',
        'Choose a parent folder for the restored app. A new PoliceTortLawAI folder will be created. '
        'Existing folders will not be overwritten. Files are verified before copying. No internet is required.')
    parent=filedialog.askdirectory(title='Choose where to install Police TortLaw AI',initialdir=os.environ.get('LOCALAPPDATA'))
    if not parent:return
    dest=Path(parent)/'PoliceTortLawAI'
    if dest.exists():raise RuntimeError('That PoliceTortLawAI folder already exists. Choose another parent folder to preserve it.')
    resolved=dest.resolve()
    if ROOT==resolved or ROOT in resolved.parents:raise RuntimeError('Choose a location outside the extracted package.')
    print('Verifying bundle integrity…',flush=True)
    verify()
    print('Copying to '+str(dest),flush=True)
    shutil.copytree(ROOT,dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc','logs'))
    # Environment variables carry paths literally; they are never interpolated into shell code.
    env=os.environ.copy();env['TORTLAW_INSTALL_DIR']=str(dest)
    code="""$ErrorActionPreference='Stop'
$desktop=[Environment]::GetFolderPath('Desktop')
$name=Join-Path $desktop 'Police TortLaw AI (Bundled).lnk'
if(Test-Path -LiteralPath $name){throw 'A bundled shortcut already exists; not overwriting it.'}
$shell=New-Object -ComObject WScript.Shell
$link=$shell.CreateShortcut($name)
$link.TargetPath=Join-Path $env:TORTLAW_INSTALL_DIR 'Start Police TortLaw AI.cmd'
$link.WorkingDirectory=$env:TORTLAW_INSTALL_DIR
$link.IconLocation=(Join-Path $env:TORTLAW_INSTALL_DIR 'python\\python.exe')+',0'
$link.Description='Police TortLaw AI with local Granite and speech recognition'
$link.Save()
"""
    result=subprocess.run([str(Path(os.environ['WINDIR'])/'System32/WindowsPowerShell/v1.0/powershell.exe'),
        '-NoProfile','-Command',code],env=env,capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    detail=('Desktop shortcut created: Police TortLaw AI (Bundled).' if result.returncode==0 else
        'Files installed, but the desktop shortcut could not be created. Open Start Police TortLaw AI.cmd in that folder.')
    messagebox.showinfo('Installation complete',str(dest)+'\n\n'+detail)
    ui.destroy()


if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('Install stopped:',exc,flush=True)
        messagebox.showerror('Installation stopped',str(exc))
        sys.exit(1)
