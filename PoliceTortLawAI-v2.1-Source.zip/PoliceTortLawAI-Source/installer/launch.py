"""Start this bundle's local server and GUI, then stop the owned server on exit."""
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import urllib.request

ROOT=Path(__file__).resolve().parent
APP=ROOT/'application'
PORT=18080


def main():
    with socket.socket() as sock:
        sock.settimeout(1)
        if sock.connect_ex(('127.0.0.1',PORT))==0:
            raise RuntimeError('The bundled app may already be running (port 18080 is occupied). Close its previous window and try again.')
    env=os.environ.copy()
    env['PATH']=str(ROOT/'runtime/cuda_v12')+os.pathsep+str(ROOT/'runtime')+os.pathsep+env.get('PATH','')
    env['GGML_BACKEND_PATH']=str(ROOT/'runtime/cuda_v12/ggml-cuda.dll')
    env['TORTLAW_AI_ENDPOINT']=f'http://127.0.0.1:{PORT}'
    env['PYTHONDONTWRITEBYTECODE']='1'
    env['PYTHONNOUSERSITE']='1'
    logs=ROOT/'logs';logs.mkdir(exist_ok=True)
    command=[str(ROOT/'runtime/llama-server.exe'),'-m',str(ROOT/'models/granite-4.0-micro-Q4_K_M.gguf'),
        '-a','local','--host','127.0.0.1','--port',str(PORT),'-c','4096','-ngl','24','-np','1','-b','256','-ub','128']
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with (logs/'server.log').open('w',encoding='utf-8') as log:
        server=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,
                                creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            print('Loading local Granite GPU model. The app will open when ready.',flush=True)
            deadline=time.monotonic()+120
            while time.monotonic()<deadline:
                if server.poll() is not None:
                    raise RuntimeError('Granite did not start. See logs/server.log; no security settings were changed.')
                try:
                    with opener.open(env['TORTLAW_AI_ENDPOINT']+'/health',timeout=1) as response:
                        if json.load(response).get('status')=='ok':break
                except (OSError,ValueError):pass
                time.sleep(.5)
            else:raise RuntimeError('Granite did not become ready within two minutes. See logs/server.log.')
            return subprocess.call([str(ROOT/'python/python.exe'),str(APP/'app/screenshot_gui.py')],cwd=APP,env=env)
        finally:
            if server.poll() is None:
                server.terminate()
                try:server.wait(timeout=10)
                except subprocess.TimeoutExpired:server.kill();server.wait()


if __name__=='__main__':
    try:sys.exit(main())
    except Exception as exc:
        print('Startup failed:',exc,flush=True)
        sys.exit(1)
