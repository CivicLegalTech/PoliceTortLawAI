"""Offline SQLite FTS5 RAG with page-aware evidence and case-summary provenance.

SQLite lexical search works offline. Optional BGE embeddings add semantic retrieval; OCR and precedent validation are NOT implemented.
"""
import hashlib
import functools
import os
import json
import pathlib
import re
import sqlite3
import sys

ROOT = pathlib.Path(getattr(sys, '_MEIPASS', pathlib.Path(__file__).resolve().parents[1]))
DATA = pathlib.Path.home() / 'PoliceTortLawAI'
DB = DATA / 'rag_index.sqlite3'
CASE_SUMMARIES = ROOT / 'data' / 'case_law' / 'research_summaries_v2_1'
SUPPORTED = {'.txt', '.md', '.csv', '.json', '.pdf', '.docx'}


def connect():
    DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB, timeout=15)
    conn.execute('PRAGMA foreign_keys=ON')
    conn.execute('CREATE TABLE IF NOT EXISTS sources (key TEXT PRIMARY KEY, digest TEXT NOT NULL, '
                 'title TEXT, kind TEXT, citation TEXT, verification_status TEXT)')
    conn.execute('CREATE TABLE IF NOT EXISTS chunks (id INTEGER PRIMARY KEY, source_key TEXT NOT NULL, '
                 'page INTEGER, part INTEGER NOT NULL, content TEXT NOT NULL, '
                 'FOREIGN KEY(source_key) REFERENCES sources(key) ON DELETE CASCADE)')
    conn.execute('CREATE INDEX IF NOT EXISTS chunk_source ON chunks(source_key)')
    conn.execute('CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(content)')
    conn.execute('CREATE TABLE IF NOT EXISTS vectors (chunk_id INTEGER PRIMARY KEY, embedding BLOB NOT NULL, model TEXT NOT NULL, FOREIGN KEY(chunk_id) REFERENCES chunks(id) ON DELETE CASCADE)')
    return conn


def split_text(text, limit=1350, overlap=180):
    text = ' '.join(str(text).split())
    if not text:
        return []
    chunks = []
    offset = 0
    while offset < len(text):
        end = min(len(text), offset + limit)
        if end < len(text):
            boundary = text.rfind(' ', offset + limit//2, end)
            if boundary > offset:
                end = boundary
        chunks.append(text[offset:end])
        if end == len(text):
            break
        offset = max(offset + 1, end - overlap)
    return chunks


def page_sections(text):
    # The existing PDF import format emits markers at each page boundary.
    parts = re.split(r'(?m)^\[Page (\d+)\]\s*\n?', str(text))
    if len(parts) == 1:
        return [(None, text)]
    result = []
    if parts[0].strip():
        result.append((None, parts[0]))
    for i in range(1, len(parts)-1, 2):
        result.append((int(parts[i]), parts[i+1]))
    return result


def _index(conn, key, title, kind, text, citation='', verification_status='unverified'):
    if not text or not str(text).strip():
        return False
    digest = hashlib.sha256(str(text).encode('utf-8')).hexdigest()
    old = conn.execute('SELECT digest FROM sources WHERE key=?', (key,)).fetchone()
    if old and old[0] == digest:
        return False
    old_ids = [r[0] for r in conn.execute('SELECT id FROM chunks WHERE source_key=?', (key,))]
    for cid in old_ids:
        conn.execute('DELETE FROM vectors WHERE chunk_id=?', (cid,))
        conn.execute('DELETE FROM chunks_fts WHERE rowid=?', (cid,))
    conn.execute('DELETE FROM chunks WHERE source_key=?', (key,))
    conn.execute('INSERT INTO sources(key,digest,title,kind,citation,verification_status) VALUES(?,?,?,?,?,?) '
                 'ON CONFLICT(key) DO UPDATE SET digest=excluded.digest,title=excluded.title,'
                 'kind=excluded.kind,citation=excluded.citation,verification_status=excluded.verification_status',
                 (key,digest,title,kind,citation,verification_status))
    n = 0
    for page, page_text in page_sections(text):
        for part, content in enumerate(split_text(page_text)):
            cur = conn.execute('INSERT INTO chunks(source_key,page,part,content) VALUES(?,?,?,?)',
                               (key,page,part,content))
            conn.execute('INSERT INTO chunks_fts(rowid,content) VALUES(?,?)', (cur.lastrowid,content))
            n += 1
    return bool(n)


def index_text(key, title, text, kind='document', citation='', verification_status='user supplied'):
    with connect() as conn:
        return _index(conn, key, title, kind, text, citation, verification_status)


def sync_library(library_db=None):
    library_db = pathlib.Path(library_db or (DATA/'library.sqlite3'))
    if not library_db.is_file():
        return 0
    source = sqlite3.connect(f'file:{library_db.as_posix()}?mode=ro', uri=True)
    added = 0
    try:
        with connect() as dest:
            for path,name,text in source.execute('SELECT path,name,text FROM documents'):
                if _index(dest, 'document:'+path, name, 'document', text,
                          verification_status='user supplied'):
                    added += 1
    except sqlite3.OperationalError:
        # Old/empty library schemas should not make the app unusable.
        return 0
    finally:
        source.close()
    return added


def index_case_summaries(source_dir=None):
    folder = pathlib.Path(source_dir or CASE_SUMMARIES)
    if not folder.is_dir():
        return 0
    count = 0
    with connect() as conn:
        for path in sorted(folder.rglob('*.json')):
            if path.name == 'index.json':
                continue
            try:
                obj = json.loads(path.read_text(encoding='utf-8'))
                if not isinstance(obj, dict) or not obj.get('case_name'):
                    continue
                name = str(obj['case_name'])
                citation = str(obj.get('citation', ''))
                content = ('Case: '+name+'\nCitation: '+citation+'\nSummary: '
                           +str(obj.get('case_summary', ''))+'\nRelevance: '
                           +str(obj.get('relevance', '')))
                if _index(conn, 'case:'+str(path.relative_to(folder)), name, 'case_summary',
                          content, citation, str(obj.get('verification_status','unverified'))):
                    count += 1
            except (ValueError, OSError):
                continue
    return count


def extract_file(path):
    path = pathlib.Path(path)
    suffix = path.suffix.lower()
    if suffix in {'.txt','.md','.csv','.json'}:
        return path.read_text(encoding='utf-8', errors='replace')
    if suffix == '.pdf':
        from pypdf import PdfReader
        return '\n'.join(f'[Page {i+1}]\n{page.extract_text() or ""}'
                         for i,page in enumerate(PdfReader(str(path)).pages))
    if suffix == '.docx':
        from docx import Document
        return '\n'.join(p.text for p in Document(str(path)).paragraphs)
    raise ValueError('Unsupported file type: '+suffix)


def ingest_path(location):
    location = pathlib.Path(location).resolve()
    if not location.exists():
        raise FileNotFoundError(location)
    paths = sorted(p for p in location.rglob('*') if p.is_file() and p.suffix.lower() in SUPPORTED) if location.is_dir() else [location]
    count=0
    with connect() as conn:
        for p in paths:
            if p.suffix.lower() not in SUPPORTED:
                continue
            try:
                content = extract_file(p)
                if _index(conn,'document:'+str(p),p.name,'document',content,
                          verification_status='user supplied'):
                    count += 1
            except (OSError,ImportError,ValueError) as exc:
                print(f'SKIPPED {p}: {exc}')
    return count


def embedding_location():
    supplied = os.environ.get('TORTLAW_EMBED_MODEL', '').strip()
    if supplied:
        return pathlib.Path(supplied)
    candidate = ROOT / 'models' / 'embeddings' / 'bge-small-en-v1.5'
    if candidate.is_dir():
        return candidate
    return DATA / 'models' / 'embeddings' / 'bge-small-en-v1.5'


@functools.lru_cache(maxsize=2)
def _load_encoder(model_path):
    # Never download automatically during analysis. Model directory must be local.
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(model_path, local_files_only=True, device='cpu')


def encoder():
    local = embedding_location()
    if not local.is_dir():
        return None
    try:
        return _load_encoder(str(local.resolve()))
    except Exception:
        return None


def build_embeddings(batch_size=32):
    """Encode chunks once on CPU, store normalized float32 vectors in local SQLite.

    Downloads are prohibited here; use the explicit setup script to obtain weights.
    """
    model = encoder()
    if model is None:
        raise RuntimeError('BGE embedding model/dependencies not found locally. See setup_embeddings_windows.bat.')
    import numpy as np
    label = str(embedding_location().resolve())
    processed = 0
    with connect() as conn:
        while True:
            rows = conn.execute("""SELECT c.id,c.content FROM chunks c
                       LEFT JOIN vectors v ON v.chunk_id=c.id AND v.model=?
                       WHERE v.chunk_id IS NULL LIMIT ?""", (label,batch_size)).fetchall()
            if not rows:
                break
            embeddings = model.encode([r[1] for r in rows], normalize_embeddings=True,
                                      batch_size=batch_size, show_progress_bar=False)
            for (chunk_id,_),vector in zip(rows, embeddings):
                embedding = np.asarray(vector, dtype=np.float32)
                conn.execute('INSERT INTO vectors(chunk_id,embedding,model) VALUES(?,?,?) '
                             'ON CONFLICT(chunk_id) DO UPDATE SET embedding=excluded.embedding,model=excluded.model',
                             (chunk_id,embedding.tobytes(),label))
                processed += 1
            conn.commit()
    return processed


def _semantic_rank(conn, question, top_n):
    label = str(embedding_location().resolve())
    vectors = conn.execute('SELECT chunk_id,embedding FROM vectors WHERE model=?',(label,)).fetchall()
    if not vectors:
        return []
    model = encoder()
    if model is None:
        return []
    import numpy as np
    query = 'Represent this sentence for searching relevant passages: ' + question
    q = np.asarray(model.encode(query,normalize_embeddings=True), dtype=np.float32).ravel()
    result = []
    for chunk_id, buffer in vectors:
        v = np.frombuffer(buffer,dtype=np.float32)
        if v.size != q.size:
            continue
        result.append((chunk_id,float(np.dot(v,q))))
    result.sort(key=lambda pair: pair[1],reverse=True)
    return [chunk_id for chunk_id,_ in result[:top_n]]


def search(query, limit=6):
    """FTS5 keyword retrieval; optionally fuse with indexed local BGE vectors."""
    terms = re.findall(r'[\w]+', str(query).lower(), flags=re.UNICODE)
    if not terms:
        return []
    limit = max(1, min(int(limit),20))
    fts = ' OR '.join('"'+term+'"' for term in dict.fromkeys(terms[:24]))
    with connect() as conn:
        conn.row_factory = sqlite3.Row
        lexical = conn.execute("""SELECT s.key,s.title,s.kind,s.citation,s.verification_status,
                    c.id,c.page,c.part,c.content,bm25(chunks_fts) AS score
                    FROM chunks_fts JOIN chunks c ON c.id=chunks_fts.rowid
                    JOIN sources s ON s.key=c.source_key WHERE chunks_fts MATCH ?
                    ORDER BY score LIMIT ?""", (fts, limit*5)).fetchall()
        lexrows = [dict(r) for r in lexical]
        semantic_ids = _semantic_rank(conn, str(query), limit*5)
        if not semantic_ids:
            return lexrows[:limit]
        semantic = {}
        for chunk_id in semantic_ids:
            row=conn.execute("""SELECT s.key,s.title,s.kind,s.citation,s.verification_status,
                        c.id,c.page,c.part,c.content FROM chunks c
                        JOIN sources s ON s.key=c.source_key WHERE c.id=?""", (chunk_id,)).fetchone()
            if row:
                semantic[chunk_id]=dict(row)
        combined = {r['id']:dict(r) for r in lexrows}
        combined.update(semantic)
        # Reciprocal rank fusion across exact text search and semantic retrieval.
        fused = {k:0.0 for k in combined}
        for rank,row in enumerate(lexrows,1):
            fused[row['id']] += 1.0/(60+rank)
        for rank,chunk_id in enumerate(semantic_ids,1):
            if chunk_id in fused:
                fused[chunk_id] += 1.0/(60+rank)
        result=sorted(combined.values(),key=lambda r:fused[r['id']],reverse=True)
        for r in result:
            r['score']=fused[r['id']]
        return result[:limit]


def stats():
    with connect() as conn:
        return {'sources':conn.execute('SELECT COUNT(*) FROM sources').fetchone()[0],
                'chunks':conn.execute('SELECT COUNT(*) FROM chunks').fetchone()[0],
                'case_summaries':conn.execute("SELECT COUNT(*) FROM sources WHERE kind='case_summary'").fetchone()[0],
                'embedded_chunks':conn.execute('SELECT COUNT(*) FROM vectors').fetchone()[0]}
