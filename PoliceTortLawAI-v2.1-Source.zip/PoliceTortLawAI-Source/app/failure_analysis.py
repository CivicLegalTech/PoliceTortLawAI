"""Transparent, rule-based issue spotting; not a legal outcome predictor."""
import re

ISSUES = [
 ("Pleading sufficiency", [r"fail(?:ure|ed)? to state a claim", r"12\\(b\\)\\(6\\)", r"plausib", r"conclusory"], "Identify each challenged element and cite the complaint paragraphs that support it. More documents do not cure an absent legal element."),
 ("Immunity", [r"qualified immunity", r"sovereign immunity", r"absolute immunity"], "Identify the defendant, capacity, claim, governing jurisdiction, and the precise immunity holding. Verify controlling precedent."),
 ("Jurisdiction and procedure", [r"subject.matter jurisdiction", r"standing", r"exhaustion", r"statute of limitations", r"notice of claim", r"untimely"], "Verify filing dates, jurisdiction, procedural prerequisites and whether the court allowed amendment."),
 ("Municipal liability", [r"monell", r"municipal liability", r"policy or custom", r"failure to train"], "Check for allegations of policy/custom, causation, and a constitutional violation; employment alone is insufficient."),
 ("Disability access", [r"americans with disabilities act", r"title ii", r"effective communication", r"reasonable modification"], "Identify the specific public service, disability-related barrier, requested accommodation (if relevant), and factual support."),
 ("Evidentiary deficiency", [r"insufficient evidence", r"no evidence", r"unsupported", r"summary judgment", r"genuine dispute"], "Identify the particular material fact the court found unsupported and what admissible evidence could address it."),
 ("No independent right", [r"no constitutional right", r"failure to investigate", r"refus(?:e|al) to take a report"], "Do not assume a police-report refusal is independently actionable; investigate only separately supported legal theories.")
]
def analyze(text, label="Imported decision"):
    findings=[]
    for title, patterns, guidance in ISSUES:
        matches=[]
        for pat in patterns:
            for m in list(re.finditer(pat,text,re.I))[:3]:
                a=max(0,m.start()-125); b=min(len(text),m.end()+145)
                matches.append(" ".join(text[a:b].split()))
        if matches:
            findings.append({"issue":title,"excerpts":matches[:3],"guidance":guidance})
    return {"source":label,"findings":findings,"note":"Keyword-based issue spotting only. Quoted excerpts are not necessarily judicial holdings. Compare the actual complaint, motion, opposition and order before concluding why a case failed."}
