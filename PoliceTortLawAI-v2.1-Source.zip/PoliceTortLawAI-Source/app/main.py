"""Minimal, offline, standard-library workflow router for TortLaw AI."""
import argparse
import json
import pathlib
import re
import sqlite3
import sys
from datetime import datetime, timezone

ROOT = pathlib.Path(getattr(sys, '_MEIPASS', pathlib.Path(__file__).resolve().parents[1]))

def load_workflows():
    result = []
    for path in sorted((ROOT / 'engines').glob('*/*.json')):
        obj = json.loads(path.read_text(encoding='utf-8'))
        obj['path'] = str(path.relative_to(ROOT))
        result.append(obj)
    return result

def route(text, workflows):
    normalized = re.sub(r'\s+', ' ', text.lower())
    matches = []
    for workflow in workflows:
        hits = [term for term in workflow['triggers'] if re.search(r'(?<!\w)' + re.escape(term.lower()) + r'(?!\w)', normalized)]
        if hits:
            matches.append({'id': workflow['id'], 'name': workflow['name'], 'side': workflow['side'],
                            'triggers_found': hits, 'status': 'candidate_only_needs_review',
                            'instructions': workflow['task'], 'requires': workflow['verification']})
    return matches

def store(db_path, matches, source):
    con = sqlite3.connect(db_path)
    con.execute('CREATE TABLE IF NOT EXISTS flags (id INTEGER PRIMARY KEY, created_utc TEXT, source TEXT, workflow_id TEXT, side TEXT, triggers TEXT, status TEXT)')
    with con:
        for item in matches:
            con.execute('INSERT INTO flags(created_utc,source,workflow_id,side,triggers,status) VALUES (?,?,?,?,?,?)',
                        (datetime.now(timezone.utc).isoformat(), source, item['id'], item['side'],
                         json.dumps(item['triggers_found']), item['status']))
    con.close()

def main():
    parser = argparse.ArgumentParser(description='Offline TortLaw AI workflow router')
    parser.add_argument('--list', action='store_true')
    parser.add_argument('--text')
    parser.add_argument('--text-file')
    parser.add_argument('--db', default=None)
    args = parser.parse_args()
    workflows = load_workflows()
    if args.list:
        for w in workflows:
            print(f"{w['id']:>4}  {w['side']:<10} {w['name']}")
        return
    if not args.text and not args.text_file:
        parser.error('Use --list, --text, or --text-file')
    text = args.text if args.text is not None else pathlib.Path(args.text_file).read_text(encoding='utf-8')
    matches = route(text, workflows)
    if args.db:
        store(args.db, matches, args.text_file or 'inline_text')
    print(json.dumps({'disclaimer':'Keyword matches are candidates, not established defenses, rebuttals, or legal conclusions.',
                      'workflow_count':len(workflows), 'matches':matches}, indent=2))

if __name__ == '__main__':
    main()
