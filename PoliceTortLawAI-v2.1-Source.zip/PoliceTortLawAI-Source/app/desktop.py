"""Police TortLaw AI — lightweight offline desktop research prototype."""
import json
import re
import zipfile
import tempfile
import shutil
import hashlib
import threading
import pathlib
import sqlite3
import sys
import wave
import queue
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
    BaseWindow = TkinterDnD.Tk
except ImportError:
    DND_FILES = None
    BaseWindow = tk.Tk
from datetime import datetime, timezone

HERE = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path(getattr(sys, '_MEIPASS', HERE.parent))
DATA = pathlib.Path.home() / 'PoliceTortLawAI'
DATA.mkdir(exist_ok=True)
sys.path.insert(0, str(HERE))
from main import load_workflows, route
from local_ai import analyze as local_analyze, status as ai_status
from failure_analysis import analyze as analyze_failure

DB = DATA / 'library.sqlite3'

def connect():
    con = sqlite3.connect(DB)
    con.execute('CREATE TABLE IF NOT EXISTS documents (id INTEGER PRIMARY KEY, name TEXT, path TEXT UNIQUE, imported_utc TEXT, text TEXT)')
    con.execute('CREATE TABLE IF NOT EXISTS evidence (id INTEGER PRIMARY KEY, document_id INTEGER, sha256 TEXT, source_type TEXT, notes TEXT DEFAULT "")')
    con.execute('CREATE VIRTUAL TABLE IF NOT EXISTS documents_fts USING fts5(name, text, content="documents", content_rowid="id")')
    con.execute('CREATE TRIGGER IF NOT EXISTS doc_insert AFTER INSERT ON documents BEGIN INSERT INTO documents_fts(rowid,name,text) VALUES(new.id,new.name,new.text); END')
    con.execute('CREATE TRIGGER IF NOT EXISTS doc_update AFTER UPDATE ON documents BEGIN INSERT INTO documents_fts(documents_fts,rowid,name,text) VALUES("delete",old.id,old.name,old.text); INSERT INTO documents_fts(rowid,name,text) VALUES(new.id,new.name,new.text); END')
    con.execute('CREATE TRIGGER IF NOT EXISTS doc_delete AFTER DELETE ON documents BEGIN INSERT INTO documents_fts(documents_fts,rowid,name,text) VALUES("delete",old.id,old.name,old.text); END')
    return con

def extract(path):
    suffix = path.suffix.lower()
    if suffix in ('.txt','.md','.csv'):
        return path.read_text(encoding='utf-8', errors='replace')
    if suffix == '.pdf':
        try:
            from pypdf import PdfReader
        except ImportError:
            raise RuntimeError('PDF support requires: pip install pypdf')
        return '\n\n'.join(f'[Page {i+1}]\n{page.extract_text() or ""}' for i,page in enumerate(PdfReader(str(path)).pages))
    if suffix == '.docx':
        try:
            from docx import Document
        except ImportError:
            raise RuntimeError('DOCX support requires: pip install python-docx')
        return '\n'.join(p.text for p in Document(str(path)).paragraphs)
    raise ValueError('Supported: PDF, DOCX, TXT, MD, CSV')

class Desktop(BaseWindow):
    def __init__(self):
        super().__init__()
        self.title('Police TortLaw AI v2.1 — Desktop')
        self.geometry('1330x820')
        self.minsize(950,620)
        self.workflows = load_workflows()
        self.con = connect()
        self.selected_text = ''
        self.selected_id = None
        self.current_report = ''
        self.mic_stream = None
        self.mic_chunks = []
        self.mic_rate = 16000
        self.recording = False
        self.flash_on = False
        self.flag_records = []
        self.configure(bg='#f4f6f9')
        self.apply_classic_style()
        self.make_ui()
        self.refresh()
        self.tabs.select(next(t for t in self.tabs.tabs() if self.tabs.tab(t,'text')=='Case Failure Analyzer'))
        self.protocol('WM_DELETE_WINDOW', self.close_app)

    def apply_classic_style(self):
        """Light early-Windows-11 inspired ttk theme, without third-party UI frameworks."""
        style = ttk.Style(self)
        if 'clam' in style.theme_names():
            style.theme_use('clam')
        bg, white, ink, muted, blue = '#f3f5f9', '#ffffff', '#202a39', '#5e6b7d', '#0067c0'
        self.configure(bg=bg)
        style.configure('.', font=('Segoe UI', 10), background=bg, foreground=ink)
        style.configure('TFrame', background=bg)
        style.configure('TLabel', background=bg, foreground=ink)
        style.configure('Muted.TLabel', background=bg, foreground=muted)
        style.configure('Header.TLabel', background=bg, foreground=ink, font=('Segoe UI', 18, 'bold'))
        style.configure('TButton', background=white, foreground=ink, padding=(12, 8), relief='flat', borderwidth=1, bordercolor='#d7dee9')
        style.map('TButton', background=[('active', '#e8f2ff'), ('pressed', '#d5e9ff')])
        style.configure('Accent.TButton', background=blue, foreground=white, padding=(14, 9), relief='flat', borderwidth=0)
        style.map('Accent.TButton', background=[('active', '#0055a1'), ('pressed', '#004782')], foreground=[('active', white)])
        style.configure('TNotebook', background=bg, borderwidth=0, tabmargins=(4, 4, 4, 0))
        style.configure('TNotebook.Tab', background='#e7ebf2', foreground='#3a485b', padding=(16, 11), borderwidth=0)
        style.map('TNotebook.Tab', background=[('selected', white), ('active', '#dceafa')], foreground=[('selected', blue)])
        style.configure('Treeview', background=white, fieldbackground=white, rowheight=29, borderwidth=0)
        style.configure('TEntry', padding=6, fieldbackground=white)
        style.configure('TLabelframe', background=bg)
        style.configure('TLabelframe.Label', background=bg, font=('Segoe UI', 10, 'bold'))
        style.configure('TProgressbar', background=blue, troughcolor='#dce3ed', borderwidth=0)

    def make_menu(self):
        menubar = tk.Menu(self, tearoff=0)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label='Import Files...', command=self.import_files)
        file_menu.add_command(label='Import Folder / ZIP...', command=self.import_bulk)
        file_menu.add_separator()
        file_menu.add_command(label='Export...', command=self.export)
        file_menu.add_separator()
        file_menu.add_command(label='Exit', command=self.close_app)
        menubar.add_cascade(label='File', menu=file_menu)
        tools = tk.Menu(menubar, tearoff=0)
        tools.add_command(label='Analyze Document', command=self.analyze)
        tools.add_command(label='Local AI', command=self.ai_analyze)
        tools.add_command(label='Complaint Builder', command=self.builder)
        tools.add_command(label='Check Citations', command=self.citations)
        tools.add_separator()
        tools.add_command(label='Start Microphone', command=self.start_microphone)
        tools.add_command(label='Stop Microphone', command=self.stop_microphone)
        menubar.add_cascade(label='Tools', menu=tools)
        self.config(menu=menubar)

    def make_ui(self):
        self.make_menu()
        self.option_add('*Font', ('Segoe UI', 10))
        bar = ttk.Frame(self, padding=(18, 15, 18, 8))
        bar.pack(fill='x')
        ttk.Label(bar, text='Police TortLaw AI', style='Header.TLabel').pack(side='left')
        ttk.Label(bar, text='LOCAL / OFFLINE   •   Legal sources require verification', style='Muted.TLabel').pack(side='right')
        toolbar = ttk.Frame(self, padding=(18, 4, 18, 10)); toolbar.pack(fill='x')
        actions = [('Import files',self.import_files),('Import folder / ZIP',self.import_bulk),('Analyze',self.analyze),('Local AI',self.ai_analyze),('Complaint builder',self.builder),('Citations',self.citations),('Export',self.export),('Start microphone',self.start_microphone),('Stop microphone',self.stop_microphone)]
        for label, fn in actions: ttk.Button(toolbar, text=label, command=fn, style='Accent.TButton' if label in ('Import files','Analyze') else 'TButton').pack(side='left', padx=(0,5))
        self.body=ttk.Frame(self)
        self.body.pack(fill='both',expand=True,padx=(12,18),pady=(0,8))
        self.sidebar=tk.Frame(self.body,bg='#edf2fa',width=206,highlightbackground='#d9e2ef',highlightthickness=1)
        self.sidebar.pack(side='left',fill='y',padx=(0,12))
        self.sidebar.pack_propagate(False)
        tk.Label(self.sidebar,text='NAVIGATION',bg='#edf2fa',fg='#5e6b7d',font=('Segoe UI',9,'bold'),anchor='w').pack(fill='x',padx=16,pady=(17,10))
        self.tabs = ttk.Notebook(self.body)
        self.tabs.pack(side='left',fill='both',expand=True)
        research = ttk.Frame(self.tabs,padding=8); self.tabs.add(research,text='Legal library')
        workflow = ttk.Frame(self.tabs,padding=8); self.tabs.add(workflow,text='Workflows')
        failure_tab = ttk.Frame(self.tabs,padding=10); self.tabs.add(failure_tab,text='Case Failure Analyzer')
        defense_tab = ttk.Frame(self.tabs,padding=10); self.tabs.add(defense_tab,text='Defense Flags')
        self.defense_tab = defense_tab
        help_tab = ttk.Frame(self.tabs,padding=12); self.tabs.add(help_tab,text='Setup & status')
        searchbar=ttk.Frame(research); searchbar.pack(fill='x',pady=(0,8))
        self.query=tk.StringVar()
        ttk.Label(searchbar,text='Search terms:').pack(side='left')
        entry=ttk.Entry(searchbar,textvariable=self.query); entry.pack(side='left',fill='x',expand=True,padx=8)
        entry.bind('<Return>',lambda _:self.search())
        ttk.Button(searchbar,text='Search',command=self.search).pack(side='left')
        ttk.Button(searchbar,text='Show all',command=lambda:(self.query.set(''),self.search())).pack(side='left',padx=5)
        panes=ttk.Panedwindow(research,orient='horizontal'); panes.pack(fill='both',expand=True)
        left=ttk.Frame(panes); right=ttk.Frame(panes)
        panes.add(left,weight=1); panes.add(right,weight=3)
        ttk.Label(left,text='Imported documents',font=('Segoe UI',10,'bold')).pack(anchor='w',pady=(0,5))
        self.docs=tk.Listbox(left,exportselection=False); self.docs.pack(fill='both',expand=True)
        self.docs.bind('<<ListboxSelect>>',self.select_document)
        ttk.Button(left,text='Document details',command=self.details).pack(fill='x',pady=(6,0))
        ttk.Button(left,text='Remove from index',command=self.remove_document).pack(fill='x',pady=(4,0))
        ttk.Label(right,text='Source preview / analysis',font=('Segoe UI',10,'bold')).pack(anchor='w',pady=(0,5))
        self.output=tk.Text(right,wrap='word',font=('Consolas',10),undo=False)
        scrollbar=ttk.Scrollbar(right,command=self.output.yview); self.output.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right',fill='y'); self.output.pack(fill='both',expand=True)
        self.write('Import PDF, DOCX, TXT, MD or CSV documents to begin.\n\nMatches are review candidates, not legal conclusions.')
        if DND_FILES:
            for widget in (self.docs,self.output):
                widget.drop_target_register(DND_FILES)
                widget.dnd_bind('<<Drop>>',self.handle_drop)
        else:
            ttk.Label(left,text='Optional: install tkinterdnd2 for drag/drop',foreground='#666').pack(anchor='w',pady=6)
        ttk.Label(workflow,text='Select a workflow to inspect its rules',font=('Segoe UI',12,'bold')).pack(anchor='w')
        wf_panes=ttk.Panedwindow(workflow,orient='horizontal'); wf_panes.pack(fill='both',expand=True,pady=8)
        wf_left=ttk.Frame(wf_panes); wf_right=ttk.Frame(wf_panes)
        wf_panes.add(wf_left,weight=1); wf_panes.add(wf_right,weight=2)
        self.workflow_list=tk.Listbox(wf_left,exportselection=False); self.workflow_list.pack(fill='both',expand=True)
        for w in self.workflows: self.workflow_list.insert('end',f"{w['id']} | {w['side']} | {w['name']}")
        self.workflow_list.bind('<<ListboxSelect>>',self.show_workflow)
        self.workflow_text=tk.Text(wf_right,wrap='word',font=('Consolas',10)); self.workflow_text.pack(fill='both',expand=True)
        ttk.Button(wf_right,text='Analyze selected document with these rules',command=self.analyze).pack(anchor='e',pady=6)
        ttk.Label(defense_tab,text='Defense flagging and plaintiff response draft',font=('Segoe UI',12,'bold')).pack(anchor='w')
        ttk.Label(defense_tab,text='Paste an argument or record speech. Transcript and rebuttal are unverified drafts; no filing is automatic.',wraplength=800).pack(anchor='w',pady=(2,8))
        self.defense_input=tk.Text(defense_tab,height=6,wrap='word',undo=True)
        self.defense_input.pack(fill='x')
        flags_controls=ttk.Frame(defense_tab); flags_controls.pack(fill='x',pady=7)
        ttk.Button(flags_controls,text='Analyze argument / draft response',command=self.generate_rebuttal).pack(side='left')
        ttk.Button(flags_controls,text='Use selected library document',command=self.use_selected_for_defense).pack(side='left',padx=6)
        ttk.Button(flags_controls,text='Save draft',command=self.save_rebuttal).pack(side='left')
        ttk.Button(flags_controls,text='Copy draft',command=self.copy_rebuttal).pack(side='left',padx=6)
        ttk.Button(flags_controls,text='Clear',command=self.clear_defense).pack(side='left')
        self.defense_status=tk.StringVar(value='No argument analyzed')
        ttk.Label(defense_tab,textvariable=self.defense_status,wraplength=800).pack(anchor='w',pady=4)
        meter_row=ttk.Frame(defense_tab); meter_row.pack(fill='x',pady=5)
        ttk.Label(meter_row,text='Detection evidence:').pack(side='left')
        self.confidence_label=tk.StringVar(value='Not assessed')
        ttk.Label(meter_row,textvariable=self.confidence_label).pack(side='left',padx=10)
        self.confidence_bar=ttk.Progressbar(meter_row,maximum=100,value=0,length=180)
        self.confidence_bar.pack(side='left',padx=8)
        ttk.Label(meter_row,text='Heuristic indicator, not a probability or legal finding').pack(side='left')
        self.rebuttal_text=tk.Text(defense_tab,wrap='word',undo=True)
        self.rebuttal_text.pack(fill='both',expand=True,pady=(4,0))
        self.rebuttal_text.insert('1.0','Draft responses appear here after analyzing a transcript or argument.\n')
        ttk.Label(failure_tab,text='Case Failure Analyzer',style='Header.TLabel').pack(anchor='w')
        ttk.Label(failure_tab,text='Review dismissed cases, identify pleading gaps and procedural barriers, and build a sourced review checklist.',wraplength=850).pack(anchor='w',pady=(2,7))
        controls=ttk.Frame(failure_tab); controls.pack(fill='x',pady=4)
        ttk.Button(controls,text='Use selected library document',command=self.failure_from_library).pack(side='left',padx=(0,6))
        ttk.Button(controls,text='Analyze case',style='Accent.TButton',command=self.run_failure_analysis).pack(side='left',padx=(0,6))
        ttk.Button(controls,text='Copy analysis',command=self.copy_failure_analysis).pack(side='left',padx=(0,6))
        ttk.Button(controls,text='Save analysis',command=self.save_failure_analysis).pack(side='left')
        ttk.Label(failure_tab,text='Court order / opinion text:').pack(anchor='w',pady=(8,2))
        self.failure_input=tk.Text(failure_tab,height=8,wrap='word',undo=True,bg='#ffffff',fg='#202a39',relief='flat',padx=12,pady=10,highlightthickness=1,highlightbackground='#d7dee9')
        self.failure_input.pack(fill='both',expand=True)
        ttk.Label(failure_tab,text='Issues, source excerpts, and review checklist:').pack(anchor='w',pady=(8,2))
        self.failure_output=tk.Text(failure_tab,height=12,wrap='word',undo=True,bg='#ffffff',fg='#202a39',relief='flat',padx=12,pady=10,highlightthickness=1,highlightbackground='#d7dee9')
        self.failure_output.pack(fill='both',expand=True)
        self.failure_output.insert('1.0','Import a decision or paste its text, then select Analyze case.\\n')
        ttk.Label(help_tab,text='Local model status',font=('Segoe UI',12,'bold')).pack(anchor='w')
        self.ai_label=ttk.Label(help_tab,text=ai_status(),wraplength=750); self.ai_label.pack(anchor='w',pady=8)
        ttk.Button(help_tab,text='Check local AI',command=self.check_ai).pack(anchor='w')
        ttk.Label(help_tab,text='Data location: '+str(DATA),wraplength=750).pack(anchor='w',pady=12)
        ttk.Button(help_tab,text='Open local data folder',command=self.open_data_folder).pack(anchor='w')
        ttk.Button(help_tab,text='Import legal sources',command=self.import_bulk).pack(anchor='w',pady=6)
        ttk.Label(help_tab,text='All analysis stays local. The local AI model and server must be installed separately.\nThis prototype does not validate legal authorities or determine filing readiness.',wraplength=750).pack(anchor='w')
        self.nav_buttons=[]
        for title,tab_name in [
            ('Case Failure Analyzer','Case Failure Analyzer'),
            ('Legal Research','Legal library'),
            ('Defense Flags','Defense Flags'),
            ('Rebuttal Worksheet','Defense Flags'),
            ('Document Library','Legal library'),
            ('Workflows (46)','Workflows'),
            ('Voice / Microphone','Defense Flags'),
            ('Settings & Status','Setup & status')]:
            btn=tk.Button(self.sidebar,text=title,anchor='w',relief='flat',bd=0,bg='#edf2fa',
                fg='#23364d',activebackground='#dceafa',activeforeground='#0067c0',
                font=('Segoe UI',10),padx=15,pady=10,cursor='hand2',
                command=lambda target=tab_name:self.navigate(target))
            btn.pack(fill='x',padx=7,pady=2)
            self.nav_buttons.append((btn,tab_name))
        self.navigate('Case Failure Analyzer')
        self.status=tk.StringVar(value='Ready')
        ttk.Label(self,textvariable=self.status,padding=7).pack(fill='x')

    def navigate(self, tab_name):
        for tab in self.tabs.tabs():
            if self.tabs.tab(tab,'text')==tab_name:
                self.tabs.select(tab)
                break
        for btn,target in getattr(self,'nav_buttons',[]):
            btn.configure(bg='#dceafa' if target==tab_name else '#edf2fa',
                          fg='#0067c0' if target==tab_name else '#23364d')

    def failure_from_library(self):
        if self.selected_id is None:
            messagebox.showinfo('Select a document','Select a document in Legal library first.')
            return
        row=self.con.execute('SELECT name,text FROM documents WHERE id=?',(self.selected_id,)).fetchone()
        if not row:
            messagebox.showwarning('Not found','Selected document is no longer indexed.')
            return
        self.failure_source=row[0]
        self.failure_input.delete('1.0','end')
        self.failure_input.insert('1.0',row[1])
        self.run_failure_analysis()
    def run_failure_analysis(self):
        content=self.failure_input.get('1.0','end-1c').strip()
        if not content:
            messagebox.showinfo('No text','Paste an order or choose an indexed document.')
            return
        result=analyze_failure(content,getattr(self,'failure_source','Pasted text'))
        lines=['SOURCE: '+result['source'],'',result['note'],'']
        for item in result['findings']:
            lines+=['ISSUE: '+item['issue'],'REVIEW: '+item['guidance']]
            lines+=['SOURCE EXCERPT: '+e for e in item['excerpts']]
            lines.append('')
        if not result['findings']:
            lines.append('No matching issue keywords detected. This does not mean the case has no deficiencies.')
        lines.append('VERIFY: Was this a complaint, motion, opposition or judicial order? Which statements are findings versus allegations? Was dismissal with or without prejudice? Is the authority binding?')
        self.failure_output.delete('1.0','end')
        self.failure_output.insert('1.0','\\n'.join(lines))
        self.tabs.select(next(t for t in self.tabs.tabs() if self.tabs.tab(t,'text')=='Case Failure Analyzer'))
    def copy_failure_analysis(self):
        value=self.failure_output.get('1.0','end-1c')
        self.clipboard_clear();self.clipboard_append(value)
        self.status.set('Case analysis copied to clipboard')
    def save_failure_analysis(self):
        filename=filedialog.asksaveasfilename(defaultextension='.txt',filetypes=[('Text files','*.txt')])
        if filename:
            pathlib.Path(filename).write_text(self.failure_output.get('1.0','end-1c'),encoding='utf-8')
            self.status.set('Case analysis saved')
    def close_app(self):
        self.recording = False
        if self.mic_stream is not None:
            self.mic_stream.stop(); self.mic_stream.close(); self.mic_stream = None
        self.con.close()
        self.destroy()

    def handle_drop(self,event):
        paths=[pathlib.Path(p) for p in self.tk.splitlist(event.data)]
        files=[]
        for path in paths:
            if path.is_dir(): files.extend(p for p in path.rglob('*') if p.is_file())
            elif path.is_file(): files.append(path)
        self.import_paths(files[:2000])

    def check_ai(self):
        self.ai_label.configure(text=ai_status()); self.refresh()

    def show_workflow(self,_=None):
        selection=self.workflow_list.curselection()
        if not selection: return
        w=self.workflows[selection[0]]
        self.workflow_text.delete('1.0','end')
        self.workflow_text.insert('1.0',json.dumps(w,indent=2,ensure_ascii=False))

    def details(self):
        if self.selected_id is None:
            messagebox.showinfo('Select document','Select a document first.'); return
        row=self.con.execute('SELECT d.name,d.path,d.imported_utc,length(d.text),e.sha256,e.source_type FROM documents d LEFT JOIN evidence e ON e.document_id=d.id WHERE d.id=?',(self.selected_id,)).fetchone()
        if row:
            self.write('DOCUMENT METADATA\n\n'+'\n'.join(f'{k}: {v}' for k,v in zip(('Name','Original path','Imported UTC','Extracted characters','SHA-256','Format'),row)))

    def remove_document(self):
        if self.selected_id is None: return
        if not messagebox.askyesno('Remove document','Remove this document from the local index? The original file will not be deleted.'): return
        with self.con:
            self.con.execute('DELETE FROM evidence WHERE document_id=?',(self.selected_id,))
            self.con.execute('DELETE FROM documents WHERE id=?',(self.selected_id,))
        self.selected_id=None; self.selected_text=''; self.refresh(); self.write('Removed from index. Original file preserved.')

    def refresh(self, rows=None):
        self.rows = rows if rows is not None else self.con.execute('SELECT id,name,path FROM documents ORDER BY id DESC').fetchall()
        self.docs.delete(0,'end')
        for _,name,_ in self.rows: self.docs.insert('end',name)
        self.status.set(f'{len(self.rows)} documents shown | {len(self.workflows)} workflows | {ai_status()}')

    def import_paths(self, paths):
        count=0; errors=[]
        for path in paths:
            path=pathlib.Path(path)
            try:
                if path.suffix.lower() not in ('.pdf','.docx','.txt','.md','.csv'):
                    continue
                if path.stat().st_size > 80 * 1024 * 1024:
                    raise ValueError('File exceeds 80 MB safety limit')
                content=extract(path)
                digest=hashlib.sha256(path.read_bytes()).hexdigest()
                with self.con:
                    self.con.execute('INSERT INTO documents(name,path,imported_utc,text) VALUES(?,?,?,?) ON CONFLICT(path) DO UPDATE SET name=excluded.name, imported_utc=excluded.imported_utc, text=excluded.text', (path.name,str(path),datetime.now(timezone.utc).isoformat(),content))
                    doc_id=self.con.execute('SELECT id FROM documents WHERE path=?',(str(path),)).fetchone()[0]
                    self.con.execute('DELETE FROM evidence WHERE document_id=?',(doc_id,))
                    self.con.execute('INSERT INTO evidence(document_id,sha256,source_type) VALUES(?,?,?)',(doc_id,digest,path.suffix.lower()))

                count+=1
            except Exception as exc:
                errors.append(f'{path.name}: {exc}')
        self.refresh()
        self.write(f'Imported or updated: {count}\n'+'\n'.join(errors))

    def import_files(self):
        files=filedialog.askopenfilenames(title='Import legal documents',filetypes=[('Legal documents','*.pdf *.docx *.txt *.md *.csv'),('All files','*.*')])
        if files: self.import_paths(files)

    def import_bulk(self):
        source=filedialog.askdirectory(title='Choose folder of legal documents (Cancel for ZIP)')
        if source:
            paths=[p for p in pathlib.Path(source).rglob('*') if p.is_file()]
            self.import_paths(paths[:2000]); return
        archive=filedialog.askopenfilename(title='Choose ZIP archive',filetypes=[('ZIP archive','*.zip')])
        if not archive: return
        with zipfile.ZipFile(archive) as z:
            members=[m for m in z.infolist() if not m.is_dir() and pathlib.Path(m.filename).suffix.lower() in ('.pdf','.docx','.txt','.md','.csv')]
            if len(members)>2000 or sum(m.file_size for m in members)>500*1024*1024:
                messagebox.showerror('Import limit','ZIP exceeds 2,000 documents or 500 MB uncompressed.');return
            # Store extracted documents persistently, not in a temporary directory.
            target=DATA/'imports'/hashlib.sha256(pathlib.Path(archive).read_bytes()).hexdigest()[:16]
            target.mkdir(parents=True,exist_ok=True)
            paths=[]
            for i,m in enumerate(members):
                dest=target/f'{i:05d}_{pathlib.Path(m.filename).name}'
                with z.open(m) as src, dest.open('wb') as dst: shutil.copyfileobj(src,dst)
                paths.append(dest)
        self.import_paths(paths)

    def start_microphone(self):
        if self.mic_stream is not None:
            messagebox.showinfo('Microphone', 'Recording is already in progress.'); return
        try:
            import sounddevice as sd
        except ImportError:
            messagebox.showwarning('Microphone unavailable', 'Install the optional sounddevice dependency to record audio.\n\npython -m pip install sounddevice'); return
        self.mic_chunks = []
        def callback(indata, frames, time_info, status):
            self.mic_chunks.append(bytes(indata))
        try:
            self.mic_stream = sd.RawInputStream(samplerate=self.mic_rate, channels=1, dtype='int16', callback=callback)
            self.mic_stream.start()
        except Exception as exc:
            self.mic_stream = None
            messagebox.showerror('Microphone unavailable', f'Could not start recording: {exc}'); return
        self.recording = True
        self.flash_defense_tab()
        self.status.set('Microphone recording — press Stop microphone to save a WAV file.')

    def stop_microphone(self):
        if self.mic_stream is None:
            messagebox.showinfo('Microphone', 'No recording is in progress.'); return
        stream = self.mic_stream
        self.mic_stream = None
        self.recording = False
        self.tabs.tab(self.defense_tab,text="Defense Flags")
        try:
            stream.stop(); stream.close()
            raw = b''.join(self.mic_chunks)
            if not raw:
                self.status.set('No audio captured'); return
            audio_dir = DATA / 'recordings'; audio_dir.mkdir(parents=True, exist_ok=True)
            dest = audio_dir / ('recording_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '.wav')
            with wave.open(str(dest), 'wb') as wav:
                wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(self.mic_rate); wav.writeframes(raw)
            self.status.set('Audio saved: ' + str(dest))
            self.write('MICROPHONE RECORDING SAVED\n' + str(dest) + '\n\nRecording is local. Transcription requires an optional offline Vosk model.')
            if messagebox.askyesno('Transcribe recording?', 'Attempt offline speech-to-text with Vosk?\nRequires vosk and a model under models/vosk.'):
                self.transcribe_audio(dest)
        except Exception as exc:
            messagebox.showerror('Recording error', str(exc))

    def transcribe_audio(self, path):
        model_dir = ROOT / 'models' / 'vosk'
        if not model_dir.is_dir():
            messagebox.showwarning('Vosk model missing', 'Place an unpacked compatible Vosk speech model in models/vosk. Recording was saved.'); return
        try:
            import vosk
        except ImportError:
            messagebox.showwarning('Vosk unavailable', 'Install optional vosk package. Recording was saved.'); return
        self.status.set('Transcribing audio locally...')
        def run():
            try:
                model = vosk.Model(str(model_dir))
                recognizer = vosk.KaldiRecognizer(model, self.mic_rate)
                transcript = []
                with wave.open(str(path), 'rb') as wav:
                    while True:
                        chunk = wav.readframes(4000)
                        if not chunk: break
                        if recognizer.AcceptWaveform(chunk):
                            transcript.append(json.loads(recognizer.Result()).get('text', ''))
                transcript.append(json.loads(recognizer.FinalResult()).get('text', ''))
                text = ' '.join(part for part in transcript if part).strip()
                transcript_path = path.with_suffix('.txt')
                transcript_path.write_text(text, encoding='utf-8')
                self.after(0, lambda: self.receive_transcript(text, transcript_path))
            except Exception as exc:
                error = str(exc)
                self.after(0, lambda: messagebox.showerror('Transcription failed', error))
            finally:
                self.after(0, self.refresh)
        threading.Thread(target=run, daemon=True).start()

    def flash_defense_tab(self):
        if not self.recording:
            self.tabs.tab(self.defense_tab,text='Defense Flags')
            return
        self.flash_on = not self.flash_on
        # ttk.Notebook does not support portable per-tab background colors.
        # A green indicator in the tab label is used instead, without pretending to recolor it.
        self.tabs.tab(self.defense_tab,text=('🟢 DEFENSE FLAGS ●' if self.flash_on else 'Defense Flags'))
        self.after(400,self.flash_defense_tab)

    def receive_transcript(self, text, transcript_path):
        self.write('UNVERIFIED MACHINE TRANSCRIPT\n'+str(transcript_path)+'\n\n'+text+'\n\nReview against the audio before relying on it.')
        self.defense_input.delete('1.0','end')
        self.defense_input.insert('1.0',text)
        self.tabs.select(self.defense_tab)
        if text.strip(): self.generate_rebuttal()
        else: self.defense_status.set('No speech recognized; recording saved.')

    def use_selected_for_defense(self):
        if not self.selected_text:
            messagebox.showinfo('Select document','Select a document from Legal library first.'); return
        self.defense_input.delete('1.0','end')
        self.defense_input.insert('1.0',self.selected_text[:16000])
        self.generate_rebuttal()

    def generate_rebuttal(self):
        text=self.defense_input.get('1.0','end-1c').strip()
        if not text:
            messagebox.showinfo('Missing argument','Enter a defense argument or transcribe speech first.');return
        matches=[m for m in route(text,self.workflows) if m['side'].lower() == 'defense']
        hypothetical=bool(re.search(r'\b(?:hypothetical|might argue|could argue|what if|for example|potential defense)\b',text,re.I))
        filed=bool(re.search(r'\b(?:defendant (?:moves|argues|asserts)|in (?:its|the) (?:motion|answer)|motion to dismiss|affirmative defense)\b',text,re.I))
        if hypothetical: posture='HYPOTHETICAL / RESEARCH ONLY'
        elif filed: posture='POSSIBLY ASSERTED — VERIFY AGAINST ACTUAL FILING'
        else: posture='UNVERIFIED SPOKEN OR WRITTEN ARGUMENT — NOT A CONFIRMED FILING'
        lines=['PLAINTIFF RESPONSE WORKSHEET — UNVERIFIED DRAFT', '', 'Procedural status: '+posture,
               'No filing deadline calculated. Confirm docket, party, governing rules, and court orders.',
               '', 'SOURCE ARGUMENT (EXCERPT):',text[:1200], '', 'CANDIDATE DEFENSES:']
        if matches:
            for m in matches[:8]:
                lines += ['- '+m['name']+' ['+m['id']+']', '  Matched phrases: '+', '.join(m['triggers_found'])]
        else: lines += ['No matching defense workflow found. Manual review required.']
        lines += ['', 'PROPOSED PLAINTIFF RESPONSE FRAMEWORK:',
                  '1. Accurately quote and cite the specific defense assertion and its source.',
                  '2. Identify the claim, parties, and procedural standard actually at issue.',
                  '3. Identify verified record facts and precise supporting paragraph/page citations.',
                  '4. Address each challenged legal element and the defense-specific burden.',
                  '5. Research controlling statutes and binding decisions; verify good-law status.',
                  '6. Determine whether a response is permitted, required, or premature.',
                  '', 'DRAFT LANGUAGE — COMPLETE ONLY WITH VERIFIED FACTS:',
                  'Plaintiff disputes the asserted defense to the extent it is inconsistent with the pleaded facts and applicable law. '
                  'The specific response must address the defendant’s actual argument, the governing standard, and verified record support. '
                  '[Insert claim-specific analysis and verified citations here.]',
                  '', 'NOT FILING READY. No authorities, facts, or deadlines have been verified by this tool.']
        self.rebuttal_text.delete('1.0','end')
        self.rebuttal_text.insert('1.0','\n'.join(lines))
        # A transparent keyword-evidence gauge, deliberately NOT an AI confidence percentage.
        # This is only a count of distinct recognized trigger phrases, capped for display.
        triggers = {phrase.casefold() for match in matches for phrase in match.get('triggers_found', [])}
        evidence_count = len(triggers)
        self.confidence_bar['value'] = min(100, evidence_count * 20)
        self.confidence_label.set(f'{evidence_count} matched phrase(s)')
        self.defense_status.set(f'{len(matches)} defense candidate(s) | {posture} | Draft populated')
        self.tabs.select(self.defense_tab)

    def copy_rebuttal(self):
        content = self.rebuttal_text.get('1.0', 'end-1c')
        self.clipboard_clear()
        self.clipboard_append(content)
        self.status.set('Draft copied to clipboard')

    def clear_defense(self):
        self.defense_input.delete('1.0', 'end')
        self.rebuttal_text.delete('1.0', 'end')
        self.defense_status.set('No argument analyzed')
        self.confidence_bar['value'] = 0
        self.confidence_label.set('Not assessed')

    def open_data_folder(self):
        import os
        import subprocess
        if sys.platform == 'win32':
            os.startfile(str(DATA))
        elif sys.platform == 'darwin':
            subprocess.Popen(['open', str(DATA)])
        else:
            subprocess.Popen(['xdg-open', str(DATA)])

    def save_rebuttal(self):
        draft=self.rebuttal_text.get('1.0','end-1c')
        path=filedialog.asksaveasfilename(defaultextension='.txt',filetypes=[('Text draft','*.txt')])
        if path:
            pathlib.Path(path).write_text(draft,encoding='utf-8')
            self.status.set('Draft saved: '+path)

    def citations(self):
        if not self.selected_text:
            messagebox.showinfo('Select document','Select an imported document first.');return
        patterns=[r'\b\d+\s+U\.S\.C\.\s*§+\s*[\w.()-]+',r'\b\d+\s+F\.\s*(?:2d|3d|4th)\s+\d+',r'\b\d+\s+U\.S\.\s+\d+',r'\b\d+\s+So\.\s*(?:2d|3d)\s+\d+',r'\b\d+\s+C\.F\.R\.\s*§+\s*[\w.()-]+']
        found=sorted(set(m.group(0) for pat in patterns for m in re.finditer(pat,self.selected_text,re.I)))
        lines=['CITATION EXTRACTION — NOT GOOD-LAW VALIDATION','']
        lines.extend(found or ['No citations recognized by basic patterns.'])
        lines.extend(['','These are text matches only. Verify case identity, pinpoint references, currency, and judicial treatment independently.'])
        self.write('\n'.join(lines))

    def search(self):
        q=self.query.get().strip()
        if not q:
            self.refresh(); return
        try:
            rows=self.con.execute('SELECT d.id,d.name,d.path FROM documents_fts f JOIN documents d ON d.id=f.rowid WHERE documents_fts MATCH ? ORDER BY rank LIMIT 200',(q,)).fetchall()
        except sqlite3.OperationalError:
            rows=self.con.execute('SELECT id,name,path FROM documents WHERE text LIKE ? OR name LIKE ? LIMIT 200',(f'%{q}%',f'%{q}%')).fetchall()
        self.selected_id=None; self.selected_text=''
        self.refresh(rows)
        self.write(f'Search: {q}\nResults: {len(rows)}\nSelect a document to view its extracted text.')

    def select_document(self,_=None):
        selection=self.docs.curselection()
        if not selection:return
        row=self.rows[selection[0]]
        result=self.con.execute('SELECT text FROM documents WHERE id=?',(row[0],)).fetchone()
        self.selected_id=row[0]
        self.selected_text=result[0] if result else ''
        self.write(f'SOURCE: {row[1]}\nPATH: {row[2]}\n\n{self.selected_text[:25000]}\n\n[Preview truncated at 25,000 characters]' if len(self.selected_text)>25000 else f'SOURCE: {row[1]}\nPATH: {row[2]}\n\n{self.selected_text}')

    def analyze(self):
        if not self.selected_text:
            messagebox.showinfo('Select document','Select an imported document first.');return
        matches=route(self.selected_text,self.workflows)
        lines=['DEFENSE / WORKFLOW CANDIDATES','Keyword detection only — verify source, procedural posture and legal authority.','']
        for m in matches:
            lines.extend([f"{m['id']} — {m['name']} ({m['side']})",f"Matched: {', '.join(m['triggers_found'])}",'Status: human review required',''])
        if not matches:lines.append('No keyword candidates detected. This does NOT establish that no defenses or claims exist.')
        self.write('\n'.join(lines))

    def ai_analyze(self):
        if not self.selected_text:
            messagebox.showinfo('Select document','Select an imported document first.'); return
        if not ai_status().startswith('AI available'):
            messagebox.showwarning('Local AI not installed', ai_status() + '\n\nSee README for setup. The search and keyword modes work without AI.'); return
        self.status.set('Local AI is analyzing the selected document...')
        self.write('Running the local model. Analysis may take longer on CPUs.\n')
        document_text = self.selected_text
        def run():
            try:
                result = local_analyze(document_text)
                self.after(0, lambda: self.write('PRELIMINARY AI ANALYSIS — NOT LEGAL ADVICE\n\n' + result + '\n\nVerify all factual and legal claims against source documents.'))
            except Exception as exc:
                error = str(exc)
                self.after(0, lambda: messagebox.showerror('Local AI error', error))
            finally:
                self.after(0, self.refresh)
        threading.Thread(target=run, daemon=True).start()

    def builder(self):
        window=tk.Toplevel(self)
        window.title('Structured Complaint Builder')
        window.geometry('690x510')
        templates=sorted((ROOT/'templates').glob('*.json'))
        choices=[]
        for path in templates:
            data=json.loads(path.read_text(encoding='utf-8'))
            choices.append((data['id']+' — '+data['title'],data))
        ttk.Label(window,text='Select an organizational template',padding=12,font=('Segoe UI',12,'bold')).pack(anchor='w')
        var=tk.StringVar(value=choices[0][0] if choices else '')
        ttk.Combobox(window,textvariable=var,values=[c[0] for c in choices],state='readonly').pack(fill='x',padx=12)
        draft=tk.Text(window,wrap='word')
        draft.pack(fill='both',expand=True,padx=12,pady=12)
        def generate():
            obj=dict(choices)[var.get()]
            lines=[obj['title'].upper(),'PRELIMINARY STRUCTURE — NOT FILING READY','']
            for i,section in enumerate(obj['sections'],1):
                lines.extend([f'{i}. {section}','[Add verified facts, applicable authority, and required allegations.]',''])
            lines.extend(['REVIEW CHECKLIST','Confirm court, jurisdiction, venue, limitations, parties, claim elements, immunity, service and signatures.','Do not file without independent legal and factual review.'])
            draft.delete('1.0','end');draft.insert('1.0','\n'.join(lines))
        controls=ttk.Frame(window); controls.pack(pady=(0,12))
        ttk.Button(controls,text='Create outline',command=generate).pack(side='left',padx=5)
        def save_draft():
            path=filedialog.asksaveasfilename(parent=window,defaultextension='.txt',filetypes=[('Text draft','*.txt')])
            if path: pathlib.Path(path).write_text(draft.get('1.0','end-1c'),encoding='utf-8')
        ttk.Button(controls,text='Save outline',command=save_draft).pack(side='left',padx=5)
        generate()

    def export(self):
        path=filedialog.asksaveasfilename(defaultextension='.txt',filetypes=[('Text report','*.txt')])
        if path:
            pathlib.Path(path).write_text(self.output.get('1.0','end'),encoding='utf-8')
            self.status.set(f'Saved report: {path}')

    def write(self,text):
        self.current_report=text
        self.output.delete('1.0','end');self.output.insert('1.0',text)

if __name__=='__main__':
    Desktop().mainloop()
