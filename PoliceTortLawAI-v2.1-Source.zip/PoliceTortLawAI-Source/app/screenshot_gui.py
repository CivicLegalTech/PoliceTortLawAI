"""Early Windows 11 inspired, functional offline case-analysis desktop interface."""
import json
import threading
import pathlib
import re
import sqlite3
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from datetime import datetime

HERE=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path(getattr(sys,'_MEIPASS',HERE.parent))
sys.path.insert(0,str(HERE))
sys.path.insert(0,str(ROOT/'vendor'))
from main import load_workflows,route
from failure_analysis import analyze as detect_issues
from local_ai import complete as local_complete, status as local_status
import rag

DATA=ROOT/'user-data'
DATA.mkdir(exist_ok=True)
rag.DATA=DATA
rag.DB=DATA/'rag_index.sqlite3'
DB=DATA/'library.sqlite3'
WORKLOAD_SETTINGS=DATA/'tab_workloads.json'
BG='#f3f6fc'; PANEL='#ffffff'; BORDER='#d6dfed'; BLUE='#0067c0'; TEXT='#18263a'; MUTED='#63758c'


def connect():
    c=sqlite3.connect(DB)
    c.execute('CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY,name TEXT,path TEXT UNIQUE,imported_utc TEXT,text TEXT)')
    c.execute('CREATE VIRTUAL TABLE IF NOT EXISTS documents_fts USING fts5(name,text,content="documents",content_rowid="id")')
    c.execute('CREATE TRIGGER IF NOT EXISTS doc_insert AFTER INSERT ON documents BEGIN INSERT INTO documents_fts(rowid,name,text) VALUES(new.id,new.name,new.text); END')
    c.commit()
    return c


def read_document(path):
    suffix=path.suffix.lower()
    if suffix in ('.txt','.md','.csv','.json'):
        return path.read_text(encoding='utf-8',errors='replace')
    if suffix=='.pdf':
        from pypdf import PdfReader
        return '\n'.join(f'[Page {i+1}]\n{p.extract_text() or ""}' for i,p in enumerate(PdfReader(str(path)).pages))
    if suffix=='.docx':
        from docx import Document
        return '\n'.join(p.text for p in Document(str(path)).paragraphs)
    raise ValueError('Unsupported format: '+suffix)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Police TortLaw AI v2.1')
        self.geometry('1440x880');self.minsize(1030,680)
        self.configure(bg=BG)
        self.conn=connect();self.workflows=load_workflows()
        self.paths=[];self.report='';self.report_items=[];self.current_page='Case Failure Analyzer';self.mode='Analysis'
        self.tab_names=['Home','Case Failure Analyzer','Legal Research','Defense Flags','Rebuttal Worksheet','Document Library','Comparative Cases','Import / Scrape','Voice (Mic)','Settings','About']
        self.keep_active=self._load_workload_settings()
        self.tab_jobs={name:set() for name in self.tab_names}
        self.tab_workers={name:set() for name in self.tab_names}
        self.tab_cancels={name:[] for name in self.tab_names}
        self.tab_frames={}

        self.nav={};self.status=tk.StringVar(value='Ready · Offline')
        self._layout();self.show_page('Case Failure Analyzer')
        from live_rebuttal import LiveRebuttal
        self.voice_library_db=DB
        self.live_voice=LiveRebuttal(self)
        self.ai_status.configure(text='Local AI\n' + ('Ready' if local_status().startswith('AI available') else 'Not connected'))
        self.protocol('WM_DELETE_WINDOW',self.close)

    def _load_workload_settings(self):
        try:
            values=json.loads(WORKLOAD_SETTINGS.read_text(encoding='utf-8'))
            if not isinstance(values,dict):raise ValueError('Invalid settings')
        except (OSError,ValueError,TypeError):values={}
        return {name:bool(values.get(name,False)) for name in self.tab_names}

    def _save_workload_settings(self):
        temp=WORKLOAD_SETTINGS.with_suffix('.tmp')
        temp.write_text(json.dumps(self.keep_active,indent=2),encoding='utf-8')
        temp.replace(WORKLOAD_SETTINGS)

    def set_keep_active(self,name,enabled):
        self.keep_active[name]=bool(enabled)
        self._save_workload_settings()
        if name==self.current_page and hasattr(self,'keep_active_var'):
            self.keep_active_var.set(bool(enabled))
        if name!=self.current_page and not enabled:self._deactivate_tab(name)

    def schedule_tab_job(self,name,delay_ms,callback):
        """Register a Tk after job; hidden tabs run only when Keep active is enabled."""
        if name not in self.tab_jobs:raise ValueError('Unknown tab')
        if name!=self.current_page and not self.keep_active[name]:return None
        job_id=None
        def run():
            self.tab_jobs[name].discard(job_id)
            if name==self.current_page or self.keep_active[name]:callback()
        job_id=self.after(delay_ms,run)
        self.tab_jobs[name].add(job_id)
        return job_id

    def register_tab_worker(self,name,worker,cancel_callback):
        """For future threaded inference/imports: callback must signal cooperative cancellation."""
        if name not in self.tab_workers:raise ValueError('Unknown tab')
        self.tab_workers[name].add(worker)
        self.tab_cancels[name].append((worker,cancel_callback))

    def unregister_tab_worker(self,name,worker):
        self.tab_workers[name].discard(worker)
        self.tab_cancels[name]=[(w,cb) for w,cb in self.tab_cancels[name] if w is not worker]

    def _deactivate_tab(self,name):
        if self.keep_active.get(name,False):return
        if name=='Voice (Mic)' and hasattr(self,'live_voice'):self.live_voice.stop()
        for job in tuple(self.tab_jobs[name]):
            try:self.after_cancel(job)
            except tk.TclError:pass
        self.tab_jobs[name].clear()
        for worker,cancel in tuple(self.tab_cancels[name]):
            try:cancel()
            except Exception:pass
        # Workers must acknowledge cancellation; never forcibly kill threads mid-write.

    def label(self,parent,text,size=10,bold=False,color=TEXT,bg=None,**kwargs):
        return tk.Label(parent,text=text,bg=bg or parent.cget('bg'),fg=color,font=('Segoe UI',size,'bold' if bold else 'normal'),**kwargs)

    def button(self,parent,text,command,primary=False):
        b=tk.Button(parent,text=text,command=command,bg=BLUE if primary else '#eaf0fa',fg='white' if primary else TEXT,
          activebackground='#00549e' if primary else '#dce8f8',activeforeground='white' if primary else TEXT,
          font=('Segoe UI',10,'bold' if primary else 'normal'),bd=0,relief='flat',cursor='hand2',padx=14,pady=10)
        return b

    def panel(self,parent):
        f=tk.Frame(parent,bg=PANEL,highlightbackground=BORDER,highlightthickness=1)
        return f

    def _layout(self):
        header=tk.Frame(self,bg='#edf3fc',height=110,highlightbackground=BORDER,highlightthickness=1)
        header.pack(fill='x');header.pack_propagate(False)
        self.label(header,'⚖',30,True,BLUE,bg='#edf3fc').pack(side='left',padx=(26,14))
        h=tk.Frame(header,bg='#edf3fc');h.pack(side='left',fill='y',pady=17)
        self.label(h,'Police TortLaw AI v2.1',24,True,bg='#edf3fc').pack(anchor='w')
        self.label(h,'Police Civil Liability  •  Tort Claims  •  Case Analysis  •  Rebuttal Tools',11,color=MUTED,bg='#edf3fc').pack(anchor='w')
        self.ai_status=self.label(header,'Local AI\nNot connected',10,True,MUTED,bg='#edf3fc',justify='center')
        self.ai_status.pack(side='right',padx=26)
        content=tk.Frame(self,bg=BG);content.pack(fill='both',expand=True)
        side=tk.Frame(content,bg='#edf3fc',width=238,highlightbackground=BORDER,highlightthickness=1)
        side.pack(side='left',fill='y');side.pack_propagate(False)
        entries=[('⌂','Home'),('⌕','Case Failure Analyzer'),('▥','Legal Research'),('◇','Defense Flags'),('▤','Rebuttal Worksheet'),('▱','Document Library'),('▥','Comparative Cases'),('⇩','Import / Scrape'),('♩','Voice (Mic)'),('⚙','Settings'),('ⓘ','About')]
        for icon,name in entries:
            b=tk.Button(side,text=f'{icon}    {name}',anchor='w',bg='#edf3fc',fg=TEXT,bd=0,relief='flat',cursor='hand2',font=('Segoe UI',11),padx=15,pady=12,command=lambda n=name:self.show_page(n))
            b.pack(fill='x',padx=9,pady=1);self.nav[name]=b
        self.main=tk.Frame(content,bg=BG);self.main.pack(side='left',fill='both',expand=True,padx=13,pady=13)
        foot=tk.Frame(self,bg='#edf3fc',height=36,highlightbackground=BORDER,highlightthickness=1)
        foot.pack(fill='x');foot.pack_propagate(False)
        self.label(foot,'●',12,color='#16a34a',bg='#edf3fc').pack(side='left',padx=(14,5))
        self.label(foot,'Ready',10,bg='#edf3fc').pack(side='left')
        self.label(foot,'Database: PoliceTortLawAI/library.sqlite3',9,color=MUTED,bg='#edf3fc').pack(side='right',padx=18)
        self.label(foot,'Documents: ',9,color=MUTED,bg='#edf3fc').pack(side='right')
        self.label(foot,'Offline · 46 workflows',9,color=MUTED,bg='#edf3fc').pack(side='right',padx=18)

    def show_page(self,name):
        previous=self.current_page
        if previous!=name:self._deactivate_tab(previous)
        self.current_page=name
        for n,b in self.nav.items():b.configure(bg='#d4e7ff' if n==name else '#edf3fc',fg=BLUE if n==name else TEXT)
        for w in self.main.winfo_children():w.destroy()
        # A page's widgets are recreated on navigation; its background work is
        # independently controlled by the per-tab Keep active setting.
        strip=tk.Frame(self.main,bg=BG)
        strip.pack(fill='x',padx=8,pady=(0,4))
        self.keep_active_var=tk.BooleanVar(value=self.keep_active[name])
        tk.Checkbutton(strip,text='Keep workload active when tab is hidden',variable=self.keep_active_var,
            command=lambda n=name:self.set_keep_active(n,self.keep_active_var.get()),
            bg=BG,fg=TEXT,activebackground=BG,selectcolor=PANEL,
            font=('Segoe UI',9),cursor='hand2').pack(side='right')
        if name=='Case Failure Analyzer':self.analyzer()
        elif name=='Document Library':self.library()
        elif name=='Legal Research':self.research()
        elif name=='Defense Flags':self.defense()
        elif name=='Rebuttal Worksheet':self.rebuttal()
        elif name=='Comparative Cases':self.comparative()
        elif name=='Import / Scrape':self.import_page()
        elif name=='Voice (Mic)':self.voice()
        elif name=='Settings':self.settings()
        elif name=='About':self.about()
        else:self.home()

    def heading(self,title,subtitle):
        self.label(self.main,title,20,True).pack(anchor='w',padx=8,pady=(4,0))
        self.label(self.main,subtitle,10,color=MUTED).pack(anchor='w',padx=8,pady=(0,15))

    def analyzer(self):
        self.heading('⚒  Case Failure Analyzer','Review unsuccessful lawsuits, identify the actual dismissal grounds, and build a better-supported case.')
        modes=tk.Frame(self.main,bg=BG);modes.pack(fill='x',pady=(0,10))
        for name in ('Analysis','Missing Elements','Procedural Issues','Legal Defenses','Fix & Rebuild'):
            self.button(modes,name,lambda n=name:self.change_mode(n),primary=name==self.mode).pack(side='left',padx=(0,5))
        body=tk.Frame(self.main,bg=BG);body.pack(fill='both',expand=True)
        left=self.panel(body);left.pack(side='left',fill='y',padx=(0,9));left.configure(width=330);left.pack_propagate(False)
        self.label(left,'1. Load Case Documents',12,True).pack(anchor='w',padx=14,pady=(14,9))
        drop=tk.Frame(left,bg='#f4f8ff',highlightbackground='#8ab8ec',highlightthickness=1,height=135)
        drop.pack(fill='x',padx=14);drop.pack_propagate(False)
        self.label(drop,'⇧',28,True,BLUE,bg='#f4f8ff').pack(pady=(10,0))
        self.label(drop,'Drag & drop documents here*',11,bg='#f4f8ff').pack()
        self.label(drop,'PDF, DOCX, TXT, MD',9,color=MUTED,bg='#f4f8ff').pack()
        self.button(left,'Browse Files',self.import_files).pack(fill='x',padx=42,pady=10)
        self.label(left,'Loaded Documents',11,True).pack(anchor='w',padx=14)
        self.docs_list=tk.Listbox(left,height=8,bg='#fff',fg=TEXT,bd=1,relief='solid',highlightthickness=0,font=('Segoe UI',9),selectbackground='#d4e7ff',selectforeground=TEXT)
        self.docs_list.pack(fill='both',expand=True,padx=14,pady=7)
        for path in self.paths:self.docs_list.insert('end',path.name)
        self.label(left,'2. Case Type (optional)',11,True).pack(anchor='w',padx=14,pady=(5,6))
        self.case_type=ttk.Combobox(left,state='readonly',values=['Police Report Refusal / Denial of Services','Excessive Force','False Arrest','ADA / Disability Discrimination','Other Police Civil Liability'])
        self.case_type.current(0);self.case_type.pack(fill='x',padx=14,pady=(0,10))
        self.button(left,'⌕  Analyze Case',self.analyze,True).pack(fill='x',padx=14,pady=(0,15))
        right=tk.Frame(body,bg=BG);right.pack(side='left',fill='both',expand=True)
        summary=self.panel(right);summary.pack(fill='x',pady=(0,8))
        self.label(summary,'▤  Analysis Summary',13,True).pack(anchor='w',padx=14,pady=(11,4))
        self.summary=self.label(summary,'No case analyzed yet. Import a court order or complaint, then click Analyze Case.',10,color=MUTED,wraplength=720,justify='left')
        self.summary.pack(anchor='w',padx=14,pady=(0,12))
        columns=tk.Frame(right,bg=BG);columns.pack(fill='both',expand=True)
        issues=self.panel(columns);issues.pack(side='left',fill='both',expand=True,padx=(0,7))
        self.label(issues,'Key Reasons / Issues',12,True).pack(anchor='w',padx=12,pady=(12,8))
        self.issue_text=tk.Text(issues,bg=PANEL,fg=TEXT,font=('Segoe UI',10),wrap='word',relief='flat',padx=12,pady=6,height=15)
        self.issue_text.pack(fill='both',expand=True);self.issue_text.insert('1.0','No findings yet.\n\nOnly source-supported issues will be shown.');self.issue_text.configure(state='disabled')
        side=tk.Frame(columns,bg=BG);side.pack(side='left',fill='both',expand=True)
        weak=self.panel(side);weak.pack(fill='both',expand=True,pady=(0,8))
        self.label(weak,'What Was Missing or Weak',12,True).pack(anchor='w',padx=12,pady=(12,7))
        self.weak_text=tk.Text(weak,bg=PANEL,fg=TEXT,font=('Segoe UI',10),wrap='word',relief='flat',padx=12,pady=4,height=8)
        self.weak_text.pack(fill='both',expand=True);self.weak_text.insert('1.0','No documents analyzed.');self.weak_text.configure(state='disabled')
        strengthen=self.panel(side);strengthen.pack(fill='both',expand=True)
        self.label(strengthen,'✓  How to Strengthen This Case',12,True,color='#16803d').pack(anchor='w',padx=12,pady=(12,7))
        self.improve_text=tk.Text(strengthen,bg=PANEL,fg=TEXT,font=('Segoe UI',10),wrap='word',relief='flat',padx=12,pady=4,height=8)
        self.improve_text.pack(fill='both',expand=True);self.improve_text.insert('1.0','Review factual support, applicable elements and controlling law.');self.improve_text.configure(state='disabled')
        actions=tk.Frame(right,bg=BG);actions.pack(fill='x',pady=(9,0))
        for text,callback in [('Generate Rebuttal Draft',self.make_rebuttal),('Create Amended Complaint Checklist',self.make_checklist),('Save Analysis',self.save_report)]:
            self.button(actions,text,callback).pack(side='left',padx=(0,6))
        if self.report:self.show_results()

    def change_mode(self,mode):
        self.mode=mode;self.analyzer_refresh()
    def analyzer_refresh(self):
        self.show_page('Case Failure Analyzer')
    def set_text(self,widget,value):
        widget.configure(state='normal');widget.delete('1.0','end');widget.insert('1.0',value);widget.configure(state='disabled')
    def import_files(self):
        names=filedialog.askopenfilenames(title='Import court documents',filetypes=[('Legal documents','*.pdf *.docx *.txt *.md *.csv'),('All files','*.*')])
        if not names:return
        errors=[]
        for name in names:
            p=pathlib.Path(name)
            try:
                content=read_document(p)
                with self.conn:self.conn.execute('INSERT OR REPLACE INTO documents(name,path,imported_utc,text) VALUES(?,?,?,?)',(p.name,str(p),datetime.utcnow().isoformat(),content))
                if p not in self.paths:self.paths.append(p)
            except Exception as exc:errors.append(f'{p.name}: {exc}')
        if errors:messagebox.showwarning('Import issues','\n'.join(errors[:10]))
        self.show_page(self.current_page)

    def analyze(self):
        if not self.paths:
            messagebox.showinfo('No documents','Import a court order or opinion before analysis.');return
        selection=self.docs_list.curselection()
        chosen=[self.paths[selection[0]]] if selection else self.paths
        text='\n\n'.join(f'FILE: {p.name}\n'+(self.conn.execute('SELECT text FROM documents WHERE path=?',(str(p),)).fetchone() or [''])[0] for p in chosen)
        if not text.strip():messagebox.showwarning('Empty documents','No extracted text found. Scanned PDFs may need OCR.');return
        res=detect_issues(text,', '.join(p.name for p in chosen))
        routed=route(text,self.workflows)
        self.report_items=res['findings'];self.routed=routed
        self.report=('SOURCE: '+res['source']+'\n'+res['note']+'\n\n'+ '\n\n'.join(f"ISSUE: {f['issue']}\nEXCERPT: {f['excerpts'][0]}\nREVIEW: {f['guidance']}" for f in res['findings'])+'\n\nWorkflow candidates: '+', '.join(w['id'] for w in routed))
        self.show_results()
        state = local_status()
        self.ai_status.configure(text='Local AI\n' + ('Ready' if state.startswith('AI available') else 'Not connected'))
        if state.startswith('AI available'):
            # Snapshot selected document text on the UI thread; SQLite connections
            # belong to the thread that created them.
            selected_contents = []
            for p in chosen[:2]:
                row = self.conn.execute('SELECT text FROM documents WHERE path=?',(str(p),)).fetchone()
                if row and row[0]:
                    selected_contents.append({'title':p.name,'content':row[0][:1600],
                          'verification_status':'user supplied','kind':'document'})
            self.analysis_run_id = getattr(self,'analysis_run_id',0)+1
            self._start_grounded_ai(selected_contents, text, self.analysis_run_id)

    def _start_grounded_ai(self, selected_contents, input_text, run_id):
        self.summary.configure(text='Rule-based issues ready. Local AI is reviewing indexed sources...')
        question = ('Analyze police-related civil-claim issues and defenses. Case type: ' +
                    self.case_type.get() + '. Analysis mode: ' + self.mode +
                    '. Explain what evidence is missing. Search terms: ' +
                    ' '.join(re.findall(r'[A-Za-z0-9]+', input_text[:2200])[:55]))
        def worker():
            try:
                rag.sync_library()
                rag.index_case_summaries()
                sources = rag.search(question, limit=7)
                # The selected document always supplies one directly identified source excerpt.
                # Other retrieved passages may include unverified case summaries.
                unique = {s['id']:s for s in sources}
                answer = local_complete(question[:1300], selected_contents + list(unique.values())[:6])
                self.after(0, lambda: self._display_local_ai(answer, run_id))
            except Exception as exc:
                error = str(exc)
                self.after(0, lambda: self._display_local_ai('Local AI could not complete: ' + error, run_id))
        threading.Thread(target=worker, daemon=True).start()

    def _display_local_ai(self, answer, run_id):
        if run_id != getattr(self,'analysis_run_id',None):
            return
        self.report += '\n\nLOCAL AI — PRELIMINARY SOURCE-CITED DRAFT\n\n' + answer
        if self.current_page == 'Case Failure Analyzer' and hasattr(self,'issue_text'):
            self.set_text(self.issue_text, 'LOCAL AI DRAFT (verify with primary sources):\n\n' + answer)
            self.summary.configure(text='Rule-based issue spotting plus local AI draft completed. Review all source citations.')

    def show_results(self):
        if not self.report:return
        self.summary.configure(text=f'{len(self.report_items)} potential issue categories identified. These are keyword candidates, not verified judicial findings.')
        self.set_text(self.issue_text,'\n\n'.join('• '+f['issue']+'\n  '+f['excerpts'][0][:230] for f in self.report_items) or 'No issue patterns detected.')
        self.set_text(self.weak_text,'\n\n'.join('□ '+f['issue']+'\n'+f['guidance'] for f in self.report_items) or 'No specific deficiencies established.')
        self.set_text(self.improve_text,'\n\n'.join('✓ '+f['guidance'] for f in self.report_items) or 'Verify claims against controlling legal elements.')

    def save_report(self):
        if not self.report:messagebox.showinfo('No analysis','Analyze documents first.');return
        name=filedialog.asksaveasfilename(defaultextension='.txt',filetypes=[('Text','*.txt')])
        if name:pathlib.Path(name).write_text(self.report,encoding='utf-8')
    def make_rebuttal(self):
        if not self.report:messagebox.showinfo('No analysis','Analyze case documents first.');return
        self.draft='REBUTTAL REVIEW WORKSHEET (not a court filing)\n\nFor each defense actually raised, identify the motion paragraph, record evidence, and controlling legal authority.\n\n'+self.report
        self.show_page('Rebuttal Worksheet')
    def make_checklist(self):
        if not self.report:messagebox.showinfo('No analysis','Analyze documents first.');return
        self.draft='AMENDED COMPLAINT REVIEW CHECKLIST (not a court filing)\n\nConfirm leave to amend, deadlines, claim elements and good-faith factual basis. Do not invent facts.\n\n'+self.report
        self.show_page('Rebuttal Worksheet')

    def generic_text(self,title,subtitle,text,buttons=None):
        self.heading(title,subtitle);p=self.panel(self.main);p.pack(fill='both',expand=True)
        self.editor=tk.Text(p,bg=PANEL,fg=TEXT,wrap='word',relief='flat',font=('Segoe UI',11),padx=18,pady=15)
        self.editor.pack(fill='both',expand=True);self.editor.insert('1.0',text)
        if buttons:
            bar=tk.Frame(self.main,bg=BG);bar.pack(fill='x',pady=8)
            for label,action in buttons:self.button(bar,label,action).pack(side='left',padx=(0,8))
    def save_editor(self):
        filename=filedialog.asksaveasfilename(defaultextension='.txt',filetypes=[('Text','*.txt')])
        if filename:pathlib.Path(filename).write_text(self.editor.get('1.0','end-1c'),encoding='utf-8')
    def rebuttal(self):
        self.generic_text('Rebuttal Worksheet','Editable working draft. Verify every factual and legal assertion.',getattr(self,'draft','Import and analyze a court document to generate a review worksheet.'),[('Save Draft',self.save_editor),('Copy Text',lambda:self.copy(self.editor.get('1.0','end-1c'))),('Live Voice Review',lambda:self.show_page('Voice (Mic)'))])
    def copy(self,text):self.clipboard_clear();self.clipboard_append(text)
    def defense(self):
        text='No analysis yet.\n\n'
        if self.report:text+='Candidate workflow flags (not defenses actually pleaded):\n'+'\n'.join(f"• {w['name']} — {', '.join(w['triggers_found'])}" for w in getattr(self,'routed',[]))
        self.generic_text('Defense Flags','Workflow candidates are not verified defenses.',text,[('Analyze Case',lambda:self.show_page('Case Failure Analyzer')),('Save Flags',self.save_editor)])
    def library(self):
        self.heading('Document Library','Locally indexed documents · SQLite FTS5')
        p=self.panel(self.main);p.pack(fill='both',expand=True)
        self.library_list=tk.Listbox(p,font=('Segoe UI',11),bg=PANEL,bd=0,selectbackground='#d4e7ff',selectforeground=TEXT)
        self.library_list.pack(fill='both',expand=True,padx=15,pady=15)
        for row in self.conn.execute('SELECT id,name FROM documents ORDER BY id DESC LIMIT 500'):self.library_list.insert('end',f'{row[0]}  {row[1]}')
        bar=tk.Frame(self.main,bg=BG);bar.pack(fill='x',pady=8)
        self.button(bar,'Import Documents',self.import_files,True).pack(side='left',padx=5)
        self.button(bar,'Open Selected in Analyzer',self.library_to_analyzer).pack(side='left',padx=5)
    def library_to_analyzer(self):
        chosen=self.library_list.curselection()
        if not chosen:return
        docid=int(self.library_list.get(chosen[0]).split()[0])
        row=self.conn.execute('SELECT path FROM documents WHERE id=?',(docid,)).fetchone()
        if row:self.paths=[pathlib.Path(row[0])];self.show_page('Case Failure Analyzer')
    def research(self):
        self.heading('Legal Research','Search documents already imported into the local library.')
        bar=tk.Frame(self.main,bg=BG);bar.pack(fill='x')
        self.search_entry=tk.Entry(bar,font=('Segoe UI',12),bg=PANEL,relief='solid',bd=1)
        self.search_entry.pack(side='left',fill='x',expand=True,padx=5,ipady=8)
        self.button(bar,'Search',self.search,True).pack(side='left')
        p=self.panel(self.main);p.pack(fill='both',expand=True,pady=10)
        self.search_output=tk.Text(p,font=('Segoe UI',10),bg=PANEL,fg=TEXT,relief='flat',wrap='word',padx=12,pady=12)
        self.search_output.pack(fill='both',expand=True)
    def search(self):
        q=self.search_entry.get().strip()
        if not q:return
        try:rows=self.conn.execute('SELECT d.name,substr(d.text,1,450) FROM documents_fts f JOIN documents d ON d.id=f.rowid WHERE documents_fts MATCH ? LIMIT 30',(q,)).fetchall()
        except sqlite3.OperationalError as e:messagebox.showerror('Search error',str(e));return
        self.search_output.delete('1.0','end')
        self.search_output.insert('1.0','\n\n'.join(f'{name}\n{snippet}' for name,snippet in rows) or 'No matches in the local database.')
    def comparative(self):
        self.generic_text('Comparative Cases','Compare judicial decisions using the case analyzer.','Import two or more opinions, then use Case Failure Analyzer. A true fact-by-fact precedent comparison engine is not yet implemented.',[('Open Analyzer',lambda:self.show_page('Case Failure Analyzer'))])
    def import_page(self):
        self.generic_text('Import / Scrape','Public legal data only; obey API terms and rate limits.','The public legal-data collector is included in tools/. It is not connected to this GUI.\n\nUse the documented CourtListener API configuration to run it separately.\n\nNo automatic PACER access or hidden downloads.',[('Import Local Files',self.import_files)])
    def voice(self):
        self.live_voice.build()
    def open_legacy(self):
        messagebox.showinfo('Legacy interface','Run: python app/desktop.py\nThe legacy desktop includes the existing microphone controls.')
    def settings(self):
        self.heading('Settings','Per-tab workload controls · saved locally')
        panel=self.panel(self.main);panel.pack(fill='both',expand=True)
        self.label(panel,'Background processing by tab',13,True).pack(anchor='w',padx=18,pady=(15,6))
        self.label(panel,'Off (default): cancel registered jobs when you leave a tab. On: allow them to continue.',10,color=MUTED).pack(anchor='w',padx=18,pady=(0,12))
        self.settings_vars={}
        for name in self.tab_names:
            var=tk.BooleanVar(value=self.keep_active[name]);self.settings_vars[name]=var
            tk.Checkbutton(panel,text=f'{name}  —  Keep active',variable=var,
                command=lambda n=name,v=var:self.set_keep_active(n,v.get()),
                bg=PANEL,fg=TEXT,activebackground=PANEL,selectcolor=PANEL,
                font=('Segoe UI',10),anchor='w').pack(fill='x',padx=20,pady=3)
        self.label(panel,'Voice starts only with Start Listening. Activity updates every 400 ms; finalized statements are reviewed sequentially. Hidden-tab listening requires Keep active.',9,color=MUTED,wraplength=800,justify='left').pack(anchor='w',padx=18,pady=(14,4))
        self.label(panel,f'Local database: {DB}  ·  Workflows: {len(self.workflows)}',9,color=MUTED).pack(anchor='w',padx=18,pady=(0,12))
    def about(self):
        self.generic_text('About','Police TortLaw AI v2.1','Windows 11-inspired Tkinter desktop prototype.\n\nCase analysis is rule-based issue spotting, not legal advice or a predictor of case outcome.\n\nDo not treat keyword matches as judicial holdings.')
    def home(self):
        self.generic_text('Home','Local police civil-liability research workspace',f'46 workflows available.\n\nUse Case Failure Analyzer to review imported opinions, motions and complaints.\n\nImport source documents before attempting analysis.',[('Open Case Failure Analyzer',lambda:self.show_page('Case Failure Analyzer')),('Import Documents',self.import_files)])
    def close(self):
        self.live_voice.close()
        for name in self.tab_names:
            self.keep_active[name]=False
            self._deactivate_tab(name)
        self.conn.close()
        self.destroy()

if __name__=='__main__':App().mainloop()
